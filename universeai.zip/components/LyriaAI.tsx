
import React, { useState, useRef, useEffect } from 'react';
import { generateComposition, transformComposition, decode, decodeAudioData } from '../services/geminiService';
import { LoadingState } from '../types';
import LoadingSpinner from './common/LoadingSpinner';
import Card from './ui/Card';
import ResetButton from './common/ResetButton';
import { useNotification } from '../hooks/useNotification';
import Button from './ui/Button';
import { SoundIcon, WandIcon } from './icons';

interface Composition {
    title: string;
    lyrics: string;
    instrumentalDescription: string;
    vocalAudio: string; // base64
}

const genres = ["Pop", "Rock", "Hip-Hop", "Electronic", "Cinematic", "Lo-fi", "Folk", "Jazz"];
const moods = ["Happy", "Sad", "Energetic", "Relaxing", "Epic", "Melancholic", "Mysterious"];
const instruments = ["Piano", "Acoustic Guitar", "Electric Guitar", "Synth", "Drums", "Strings", "Female Vocals", "Male Vocals"];

const getInitialState = <T,>(key: string, defaultValue: T): T => {
    try {
        const savedState = localStorage.getItem(`lyriaAI_v2_${key}`);
        return savedState ? JSON.parse(savedState) : defaultValue;
    } catch (error) {
        console.error(`Failed to parse ${key} from localStorage`, error);
        return defaultValue;
    }
};

const LyriaAI: React.FC = () => {
    const [prompt, setPrompt] = useState(() => getInitialState('prompt', ''));
    const [selectedGenre, setSelectedGenre] = useState(() => getInitialState('genre', 'Pop'));
    const [selectedMood, setSelectedMood] = useState(() => getInitialState('mood', 'Happy'));
    const [selectedInstruments, setSelectedInstruments] = useState<string[]>(() => getInitialState('instruments', ['Piano', 'Female Vocals']));
    const [composition, setComposition] = useState<Composition | null>(() => getInitialState('composition', null));
    const [transformPrompt, setTransformPrompt] = useState('');
    
    const [loading, setLoading] = useState<LoadingState>('idle');
    const [transformLoading, setTransformLoading] = useState<LoadingState>('idle');
    const [error, setError] = useState<string | null>(null);

    const [isPlaying, setIsPlaying] = useState(false);
    const audioContextRef = useRef<AudioContext | null>(null);
    const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);
    const addNotification = useNotification();

    // Persist state
    useEffect(() => { localStorage.setItem('lyriaAI_v2_prompt', JSON.stringify(prompt)); }, [prompt]);
    useEffect(() => { localStorage.setItem('lyriaAI_v2_genre', JSON.stringify(selectedGenre)); }, [selectedGenre]);
    useEffect(() => { localStorage.setItem('lyriaAI_v2_mood', JSON.stringify(selectedMood)); }, [selectedMood]);
    useEffect(() => { localStorage.setItem('lyriaAI_v2_instruments', JSON.stringify(selectedInstruments)); }, [selectedInstruments]);
    useEffect(() => { localStorage.setItem('lyriaAI_v2_composition', JSON.stringify(composition)); }, [composition]);

    // Initialize Web Audio API
    useEffect(() => {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        return () => { audioContextRef.current?.close(); };
    }, []);
    
    const playAudio = async (base64Audio: string) => {
        if (audioSourceRef.current) {
            audioSourceRef.current.stop();
        }
        if (!audioContextRef.current) return;
        
        try {
            const audioBuffer = await decodeAudioData(decode(base64Audio), audioContextRef.current, 24000, 1);
            const source = audioContextRef.current.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(audioContextRef.current.destination);
            source.onended = () => setIsPlaying(false);
            source.start();
            audioSourceRef.current = source;
            setIsPlaying(true);
        } catch(e) {
            console.error("Failed to play audio", e);
            addNotification("Could not play the generated audio.", 'error');
        }
    };

    const handleReset = () => {
        setPrompt('');
        setSelectedGenre('Pop');
        setSelectedMood('Happy');
        setSelectedInstruments(['Piano', 'Female Vocals']);
        setComposition(null);
        setTransformPrompt('');
        setLoading('idle');
        setTransformLoading('idle');
        setError(null);
        if (audioSourceRef.current) audioSourceRef.current.stop();
        setIsPlaying(false);
        Object.keys(localStorage).forEach(key => {
            if (key.startsWith('lyriaAI_v2_')) localStorage.removeItem(key);
        });
        addNotification('Lyria AI has been reset.', 'info');
    };
    
    const handleInstrumentToggle = (instrument: string) => {
        setSelectedInstruments(prev => 
            prev.includes(instrument) 
                ? prev.filter(i => i !== instrument) 
                : [...prev, instrument]
        );
    };

    const handleCompose = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!prompt.trim()) return;
        setLoading('loading');
        setError(null);
        setComposition(null);
        if (audioSourceRef.current) audioSourceRef.current.stop();

        try {
            const result = await generateComposition(prompt, selectedGenre, selectedMood, selectedInstruments);
            setComposition(result);
            setLoading('success');
            await playAudio(result.vocalAudio);
        } catch (err: any) {
            console.error(err);
            setError(err.message || 'Failed to generate composition.');
            setLoading('error');
        }
    };
    
    const handleTransform = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!transformPrompt.trim() || !composition) return;
        setTransformLoading('loading');
        setError(null);
        if (audioSourceRef.current) audioSourceRef.current.stop();

        try {
            const original = { title: composition.title, lyrics: composition.lyrics, instrumentalDescription: composition.instrumentalDescription };
            const result = await transformComposition(original, transformPrompt);
            setComposition(result);
            setTransformPrompt('');
            setTransformLoading('success');
            await playAudio(result.vocalAudio);
        } catch (err: any) {
            console.error(err);
            setError(err.message || 'Failed to transform composition.');
            setTransformLoading('error');
        }
    };

    const TagSelector: React.FC<{title: string, items: string[], selected: string | string[], onSelect: (item: string) => void}> = ({ title, items, selected, onSelect }) => (
        <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">{title}</label>
            <div className="flex flex-wrap gap-2">
                {items.map(item => {
                    const isSelected = Array.isArray(selected) ? selected.includes(item) : selected === item;
                    return <Button key={item} type="button" variant={isSelected ? 'primary' : 'secondary'} onClick={() => onSelect(item)}>{item}</Button>
                })}
            </div>
        </div>
    );
    
    return (
        <div className="max-w-4xl mx-auto animate-fade-in">
            <Card
                title="Lyria AI Music Generation"
                description="The original Lyria is a sophisticated and specialized AI model from Google DeepMind designed specifically for music generation. It can create instrumental pieces and vocal melodies, transform musical styles, and perform more complex audio-based tasks."
                actions={<ResetButton onReset={handleReset} />}
            >
                <form onSubmit={handleCompose} className="space-y-4">
                    <textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Describe your song idea... e.g., 'A song about exploring a new city at night'" className="w-full bg-gray-900/50 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500 min-h-[80px]" required />
                    <TagSelector title="Genre" items={genres} selected={selectedGenre} onSelect={(item) => setSelectedGenre(item)} />
                    <TagSelector title="Mood" items={moods} selected={selectedMood} onSelect={(item) => setSelectedMood(item)} />
                    <TagSelector title="Instruments / Vocals" items={instruments} selected={selectedInstruments} onSelect={handleInstrumentToggle} />
                    <Button type="submit" disabled={loading === 'loading'} className="w-full">
                        {loading === 'loading' ? 'Composing...' : 'Compose with Lyria AI'}
                    </Button>
                </form>

                {loading === 'loading' && <div className="mt-4"><LoadingSpinner /></div>}
                {error && !composition && <p className="text-red-400 text-center mt-4">{error}</p>}
                
                {composition && (
                    <div className="mt-6 p-4 bg-gray-900/50 rounded-lg space-y-4 animate-fade-in">
                        <h3 className="text-2xl font-bold text-center text-purple-300">{composition.title}</h3>
                        
                        <div className="flex justify-center">
                            <Button variant="secondary" onClick={() => playAudio(composition.vocalAudio)} disabled={isPlaying}>
                                <div className="flex items-center gap-2">
                                    <SoundIcon />
                                    {isPlaying ? 'Playing...' : 'Play Vocal Melody'}
                                </div>
                            </Button>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                            <div>
                                <h4 className="font-semibold text-purple-400 mb-2">Lyrics</h4>
                                <p className="whitespace-pre-wrap text-gray-300 bg-gray-800/50 p-3 rounded-md">{composition.lyrics}</p>
                            </div>
                             <div>
                                <h4 className="font-semibold text-purple-400 mb-2">Instrumental Arrangement</h4>
                                <p className="text-gray-300 bg-gray-800/50 p-3 rounded-md">{composition.instrumentalDescription}</p>
                            </div>
                        </div>
                        
                        <div className="border-t border-gray-700 pt-4 mt-4">
                             <h4 className="font-semibold text-lg text-purple-400 mb-2">Transform Style</h4>
                             <form onSubmit={handleTransform} className="space-y-3">
                                <input type="text" value={transformPrompt} onChange={e => setTransformPrompt(e.target.value)} placeholder="e.g., 'Make it a fast-paced punk rock version' or 'turn it into a slow, acoustic ballad'" className="w-full bg-gray-900/50 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500" />
                                <Button type="submit" variant="secondary" disabled={transformLoading === 'loading'} className="w-full">
                                    <div className="flex items-center justify-center gap-2">
                                        <WandIcon />
                                        {transformLoading === 'loading' ? 'Transforming...' : 'Transform'}
                                    </div>
                                </Button>
                                {transformLoading === 'loading' && <LoadingSpinner />}
                             </form>
                        </div>
                        {error && <p className="text-red-400 text-center mt-4">{error}</p>}
                    </div>
                )}
            </Card>
        </div>
    );
};

export default LyriaAI;