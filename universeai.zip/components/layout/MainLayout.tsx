
import React from 'react';
import { Feature } from '../../types';
import NotificationContainer from '../ui/Notification';

interface MainLayoutProps {
    children: React.ReactNode;
    activeFeature: Feature;
    isSidebarCollapsed: boolean;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children, activeFeature, isSidebarCollapsed }) => {
    // The UniverseAI Core has its own internal layout, so we don't apply the standard padding and max-width.
    const isCoreActive = activeFeature === Feature.UniverseAICore;

    return (
        <main className={`flex-1 overflow-y-auto relative transition-all duration-300 ease-in-out ${isSidebarCollapsed ? 'ml-20' : 'ml-64'}`}>
            <NotificationContainer />
            <div className={isCoreActive ? "h-full" : "p-4 md:p-8"}>
                <div className={isCoreActive ? "h-full" : "max-w-7xl mx-auto"}>
                    {children}
                </div>
            </div>
        </main>
    );
};

export default MainLayout;