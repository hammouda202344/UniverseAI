import React from 'react';

interface CardProps {
  children: React.ReactNode;
  title?: string;
  description?: string;
  className?: string;
  actions?: React.ReactNode;
}

const Card: React.FC<CardProps> = ({ children, title, description, className = '', actions }) => {
  const hasHeader = title || description || actions;
  return (
    <div className={`bg-gray-900/40 border border-purple-500/20 rounded-xl shadow-2xl shadow-purple-900/20 backdrop-blur-lg ${className}`}>
      {hasHeader && (
        <div className="p-6 border-b border-purple-500/20 flex justify-between items-start gap-4">
          <div className="flex-grow">
            {title && <h2 className="text-2xl font-semibold text-violet-400">{title}</h2>}
            {description && <p className="text-gray-400 mt-1">{description}</p>}
          </div>
          {actions && <div className="flex-shrink-0">{actions}</div>}
        </div>
      )}
      <div className="p-6 space-y-6">
        {children}
      </div>
    </div>
  );
};

export default Card;