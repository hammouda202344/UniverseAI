
import React, { useContext } from 'react';
import { NotificationContext } from '../../context/NotificationContext';
import { NotificationType } from '../../types';
import { XMarkIcon } from '../icons';

const notificationStyles: Record<NotificationType, { bg: string; border: string; text: string }> = {
  success: { bg: 'bg-green-500/20', border: 'border-green-500', text: 'text-green-300' },
  error: { bg: 'bg-red-500/20', border: 'border-red-500', text: 'text-red-300' },
  info: { bg: 'bg-blue-500/20', border: 'border-blue-500', text: 'text-blue-300' },
};

const NotificationContainer: React.FC = () => {
  const context = useContext(NotificationContext);

  if (!context) {
    return null;
  }

  const { notifications, removeNotification } = context;

  return (
    <div className="fixed top-5 right-5 z-50 w-full max-w-sm space-y-3">
      {notifications.map((notification) => {
        const styles = notificationStyles[notification.type];
        return (
          <div
            key={notification.id}
            className={`flex items-center justify-between p-4 rounded-lg shadow-lg border-l-4 animate-fade-in-right ${styles.bg} ${styles.border}`}
          >
            <p className={`text-sm ${styles.text}`}>{notification.message}</p>
            <button onClick={() => removeNotification(notification.id)} className="text-gray-400 hover:text-white">
              <XMarkIcon />
            </button>
            <style>{`
              @keyframes fade-in-right {
                from { opacity: 0; transform: translateX(20px); }
                to { opacity: 1; transform: translateX(0); }
              }
              .animate-fade-in-right { animation: fade-in-right 0.3s ease-out forwards; }
            `}</style>
          </div>
        );
      })}
    </div>
  );
};

export default NotificationContainer;