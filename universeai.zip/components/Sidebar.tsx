
import React from 'react';
import { Feature } from '../types';
import { EditIcon, EyeIcon, ImageIcon, MicrophoneIcon, SearchIcon, SoundIcon, VideoIcon, WandIcon, BookIcon, UniverseAICoreIcon, HomeIcon, Bars3Icon, XMarkIcon, VideoEditIcon, ImageToVideoIcon, MusicIcon, AnimeIcon } from './icons';

interface SidebarProps {
  activeFeature: Feature;
  setActiveFeature: (feature: Feature) => void;
  isCollapsed: boolean;
  toggleSidebar: () => void;
}

const featureList = [
  { id: Feature.Home, icon: <HomeIcon />, label: 'Home' },
  { id: Feature.UniverseAICore, icon: <UniverseAICoreIcon />, label: 'UniverseAI Core' },
  { id: Feature.ImageGeneration, icon: <ImageIcon />, label: 'Image Generation' },
  { id: Feature.ImageEditing, icon: <EditIcon />, label: 'Image Editing' },
  { id: Feature.AnimeProductionStudio, icon: <AnimeIcon />, label: 'Anime Production Studio' },
  { id: Feature.ImageAnalysis, icon: <EyeIcon />, label: 'Image Analysis' },
  { id: Feature.VideoGeneration, icon: <VideoIcon />, label: 'Video Generation' },
  { id: Feature.VideoEditing, icon: <VideoEditIcon />, label: 'Video Editing' },
  { id: Feature.ImageToVideo, icon: <ImageToVideoIcon />, label: 'Image to Video' },
  { id: Feature.VideoAnalysis, icon: <WandIcon />, label: 'Video Analysis' },
  { id: Feature.LiveConversation, icon: <MicrophoneIcon isLive />, label: 'Live Conversation' },
  { id: Feature.GroundingSearch, icon: <SearchIcon />, label: 'Grounded Search' },
  { id: Feature.TextToSpeech, icon: <SoundIcon />, label: 'Text to Speech' },
  { id: Feature.EbookGeneration, icon: <BookIcon />, label: 'Ebook Generation' },
  { id: Feature.LyriaAI, icon: <MusicIcon />, label: 'Lyria AI' },
];

const Sidebar: React.FC<SidebarProps> = ({ activeFeature, setActiveFeature, isCollapsed, toggleSidebar }) => {
  return (
    <aside className={`bg-gray-900/50 backdrop-blur-lg text-white flex flex-col fixed top-0 left-0 h-full border-r border-gray-700/50 transition-all duration-300 ease-in-out z-10 ${isCollapsed ? 'w-20' : 'w-64'}`}>
      <div className={`flex items-center border-b border-gray-700/50 transition-all duration-300 shrink-0 ${isCollapsed ? 'h-16 justify-center' : 'h-16 px-4'}`}>
        <div className="w-8 h-8">
            <UniverseAICoreIcon />
        </div>
        {!isCollapsed && <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-violet-400 to-indigo-500 ml-2 tracking-tight">AI Studio Pro</span>}
      </div>

      <nav className="flex-grow p-2 space-y-1 overflow-y-auto">
        <ul>
          {featureList.map((feature) => (
            <li key={feature.id}>
              <button
                onClick={() => setActiveFeature(feature.id)}
                title={feature.label}
                className={`w-full text-left flex items-center space-x-3 p-3 rounded-md transition-all duration-200 group relative ${
                  activeFeature === feature.id
                    ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg'
                    : 'text-gray-300 hover:bg-gray-700/50 hover:text-white'
                } ${isCollapsed ? 'justify-center' : ''}`}
              >
                <div className="w-6 h-6">{feature.icon}</div>
                {!isCollapsed && <span className="flex-1 font-medium">{feature.label}</span>}
                {isCollapsed && (
                    <span className="absolute left-full ml-4 w-auto p-2 min-w-max rounded-md shadow-md text-white bg-gray-800 text-xs font-bold transition-all duration-100 scale-0 origin-left group-hover:scale-100 z-20">
                        {feature.label}
                    </span>
                )}
              </button>
            </li>
          ))}
        </ul>
      </nav>

      <div className="p-2 border-t border-gray-700/50 shrink-0">
         <button
            onClick={toggleSidebar}
            className={`w-full text-left flex items-center space-x-3 p-3 rounded-md transition-colors duration-200 text-gray-300 hover:bg-gray-700/50 hover:text-white ${isCollapsed ? 'justify-center' : ''}`}
          >
            {isCollapsed ? <Bars3Icon /> : <XMarkIcon />}
            {!isCollapsed && <span className="font-medium">Collapse</span>}
          </button>
      </div>
    </aside>
  );
};

export default Sidebar;