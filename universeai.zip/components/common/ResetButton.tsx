
import React from 'react';
import { ArrowPathIcon } from '../icons';

interface ResetButtonProps {
  onReset: () => void;
  className?: string;
}

const ResetButton: React.FC<ResetButtonProps> = ({ onReset, className }) => (
  <button
    onClick={onReset}
    className={`text-gray-400 hover:text-white transition-colors p-2 rounded-full hover:bg-gray-700 ${className}`}
    aria-label="Reset feature state"
    title="Reset"
  >
    <ArrowPathIcon />
  </button>
);

export default ResetButton;