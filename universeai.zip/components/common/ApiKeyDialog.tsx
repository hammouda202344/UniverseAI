
import React from 'react';

interface ApiKeyDialogProps {
  onSelectKey: () => void;
}

const ApiKeyDialog: React.FC<ApiKeyDialogProps> = ({ onSelectKey }) => {
  return (
    <div className="bg-gray-700 p-6 rounded-lg shadow-xl text-center">
      <h3 className="text-xl font-bold mb-4">API Key Required</h3>
      <p className="text-gray-300 mb-4">
        Video generation with Veo requires you to select your own API key.
        This feature may incur charges on your Google Cloud project.
      </p>
      <p className="text-sm text-gray-400 mb-6">
        Please see the <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-purple-400 hover:underline">billing documentation</a> for more information.
      </p>
      <button
        onClick={onSelectKey}
        className="w-full bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-700 transition-colors duration-200"
      >
        Select API Key
      </button>
    </div>
  );
};

export default ApiKeyDialog;
