
import React, { useState, useEffect } from 'react';
import { analyzeImage, fileToDataURL, dataURLtoFile } from '../services/geminiService';
import { LoadingState } from '../types';
import LoadingSpinner from './common/LoadingSpinner';
import Card from './ui/Card';
import ResetButton from './common/ResetButton';
import { useNotification } from '../hooks/useNotification';

const ImageAnalyzer: React.FC = () => {
    const [prompt, setPrompt] = useState(() => localStorage.getItem('imageAnalyzer_prompt') || 'What is in this picture?');
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [analysis, setAnalysis] = useState<string | null>(() => localStorage.getItem('imageAnalyzer_analysis') || null);
    const [loading, setLoading] = useState<LoadingState>('idle');
    const [error, setError] = useState<string | null>(null);
    const addNotification = useNotification();

    // Load initial state from localStorage
    useEffect(() => {
        const savedImage = localStorage.getItem('imageAnalyzer_imageDataUrl');
        if (savedImage) {
            setImageUrl(savedImage);
            const file = dataURLtoFile(savedImage, 'uploaded-image');
            if (file) {
                setImageFile(file);
            }
        }
    }, []);

     useEffect(() => {
        localStorage.setItem('imageAnalyzer_prompt', prompt);
    }, [prompt]);

    useEffect(() => {
        if (analysis) {
            localStorage.setItem('imageAnalyzer_analysis', analysis);
        } else {
            localStorage.removeItem('imageAnalyzer_analysis');
        }
    }, [analysis]);

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setImageFile(file);
            const dataUrl = await fileToDataURL(file);
            setImageUrl(dataUrl);
            localStorage.setItem('imageAnalyzer_imageDataUrl', dataUrl);
            setAnalysis(null);
        }
    };

    const handleReset = () => {
        setPrompt('What is in this picture?');
        setImageFile(null);
        setImageUrl(null);
        setAnalysis(null);
        setLoading('idle');
        setError(null);
        localStorage.removeItem('imageAnalyzer_prompt');
        localStorage.removeItem('imageAnalyzer_imageDataUrl');
        localStorage.removeItem('imageAnalyzer_analysis');
        addNotification('Image Analyzer reset.', 'info');
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!prompt.trim() || !imageFile) return;

        setLoading('loading');
        setAnalysis(null);
        setError(null);
        try {
            const result = await analyzeImage(prompt, imageFile);
            setAnalysis(result);
            setLoading('success');
        } catch (err) {
            console.error(err);
            setError('Failed to analyze image. Please try again.');
            setLoading('error');
        }
    };

    return (
        <div className="max-w-4xl mx-auto animate-fade-in">
            <Card
                title="Image Understanding"
                description="Upload an image and ask questions about it to get detailed insights."
                actions={<ResetButton onReset={handleReset} />}
            >
                <div className="space-y-4">
                    <div>
                        <label htmlFor="image-upload" className="block text-sm font-medium text-gray-300 mb-1">Upload Image</label>
                        <input
                            id="image-upload"
                            type="file"
                            accept="image/*"
                            onChange={handleFileChange}
                            className="w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-purple-600 file:text-white hover:file:bg-purple-700"
                        />
                    </div>
                     {imageUrl && <img src={imageUrl} alt="Uploaded preview" className="rounded-lg shadow-lg mx-auto max-w-full max-h-80" />}

                    <form onSubmit={handleSubmit} className="space-y-4">
                        <textarea
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="e.g., What is in this picture? Provide details about the main subject."
                            className="w-full bg-gray-900/50 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500 min-h-[80px]"
                            required
                            disabled={!imageFile}
                        />
                        <button
                            type="submit"
                            className="w-full bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-700 transition-colors disabled:bg-gray-500"
                            disabled={loading === 'loading' || !prompt.trim() || !imageFile}
                        >
                            {loading === 'loading' ? 'Analyzing...' : 'Analyze Image'}
                        </button>
                    </form>
                </div>

                {loading === 'loading' && <div className="mt-4"><LoadingSpinner /></div>}
                {error && <p className="text-red-400 text-center mt-4">{error}</p>}
                
                {analysis && (
                    <div className="mt-6 p-4 bg-gray-900/50 rounded-lg">
                        <h3 className="text-lg font-semibold mb-2 text-purple-300">Analysis Result:</h3>
                        <p className="whitespace-pre-wrap text-gray-200">{analysis}</p>
                    </div>
                )}
            </Card>
        </div>
    );
};

export default ImageAnalyzer;