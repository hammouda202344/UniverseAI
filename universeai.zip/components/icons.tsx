
import React from 'react';

const iconGradientId = "icon-gradient";
const IconGradientDef = () => (
    <defs>
        <linearGradient id={iconGradientId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style={{ stopColor: '#A855F7', stopOpacity: 1 }} />
            <stop offset="100%" style={{ stopColor: '#6366F1', stopOpacity: 1 }} />
        </linearGradient>
    </defs>
);

export const HomeIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M12 2L2 12h3v8h14v-8h3L12 2zm0 2.69l7 6.31V20h-4v-6H9v6H5V8.99l7-6.3z" fill={`url(#${iconGradientId})`}/>
        <path d="M12 5.5l1.5 3 3 1.5-3 1.5-1.5 3-1.5-3-3-1.5 3-1.5 1.5-3z" fill="white"/>
    </svg>
);

export const XMarkIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);

export const XIcon = XMarkIcon; // Alias for backwards compatibility

export const ImageIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M21 3H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM3 19V5h18v14H3z" fill={`url(#${iconGradientId})`}/>
        <path d="M14.5 11l-3 4-2-2-4.5 6h14l-5-6.5z" fill={`url(#${iconGradientId})`}/>
        <path d="M7 8.5c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5-1.5-.67-1.5-1.5.67-1.5 1.5-1.5z" fill="white"/>
    </svg>
);

export const VideoIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z" fill={`url(#${iconGradientId})`}/>
        <path d="M9 12l1.5 3 3 1.5-3 1.5-1.5 3-1.5-3-3-1.5 3-1.5 1.5-3z" fill="white"/>
    </svg>
);

export const SearchIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M15.5 14h-.79l-.28-.27a6.5 6.5 0 001.48-5.34C15.91 5.16 13.24 2.5 10 2.5 6.13 2.5 3 5.63 3 9.5 3 13.37 6.13 16.5 10 16.5c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-5.5 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" fill={`url(#${iconGradientId})`}/>
        <path d="M9.5 7.5l1 2 2 1-2 1-1 2-1-2-2-1 2-1 1-2z" fill="white"/>
    </svg>
);

export const BrainIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M4.871 14.836c-1.143-1.395-1.871-3.06-1.871-4.836 0-4.418 4.03-8 9-8s9 3.582 9 8c0 1.776-.728 3.441-1.871 4.836M6 18c-1.333-1.333-2-3-2-4.664M18 18c1.333-1.333 2-3 2-4.664M12 21v-3.336M12 3v3.336" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M7.5 12.5c0-2.485 2.015-4.5 4.5-4.5s4.5 2.015 4.5 4.5" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M7.5 15.5c0 2.485 2.015 4.5 4.5 4.5s4.5-2.015 4.5-4.5" />
    </svg>
);

export const EditIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a.9959.9959 0 00-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" fill={`url(#${iconGradientId})`}/>
        <path d="M14.5 5l.5 1 1 .5-1 .5-.5 1-.5-1-1-.5 1-.5.5-1z" fill="white"/>
        <path d="M5.5 15l.5 1 1 .5-1 .5-.5 1-.5-1-1-.5 1-.5.5-1z" fill="white"/>
    </svg>
);

export const VideoEditIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M18 4H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zM8 16.5H6.5v-1.5H8v1.5zm0-3H6.5v-1.5H8v1.5zm0-3H6.5V9H8v1.5zm4 3h-1.5v-1.5H12v1.5zm0-3h-1.5V9H12v1.5zm4 3h-1.5v-1.5H16v1.5zm0-3h-1.5V9H16v1.5zm-8-3H6.5V6H8v1.5z" fill={`url(#${iconGradientId})`}/>
        <path d="M19.04 7.39l-2.43-2.43a.996.996 0 00-1.41 0l-.7.7 3.84 3.84.7-.7c.39-.38.39-1.02 0-1.41zM11 13.5V17.34l3.12-3.12-2.82-2.82L11 11.72V13.5z" fill="white"/>
    </svg>
);

export const ImageToVideoIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M14 10v4l3-2-3-2z" fill="white"/>
        <path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V6h16v12z" fill={`url(#${iconGradientId})`}/>
    </svg>
);

export const AnimeIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1.5 14.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm3 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM12 9.5c-1.63 0-3.08.8-4 2 .92 1.2 2.37 2 4 2s3.08-.8 4-2c-.92-1.2-2.37-2-4-2z" fill={`url(#${iconGradientId})`}/>
        <path d="M12 12.5l-.5-1-1-.5 1-.5.5-1 .5 1 1 .5-1 .5.5 1z" fill="white"/>
    </svg>
);

export const EyeIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5C21.27 7.61 17 4.5 12 4.5zm0 12c-2.48 0-4.5-2.02-4.5-4.5s2.02-4.5 4.5-4.5 4.5 2.02 4.5 4.5-2.02 4.5-4.5 4.5z" fill={`url(#${iconGradientId})`}/>
        <path d="M12 9.5l.5 1 1 .5-1 .5-.5 1-.5-1-1-.5 1-.5.5-1z" fill="white"/>
    </svg>
);

export const SoundIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z" fill={`url(#${iconGradientId})`}/>
        <path d="M18.5 12l.5 1 1 .5-1 .5-.5 1-.5-1-1-.5 1-.5.5-1z" fill="white"/>
    </svg>
);

// FIX: Corrected invalid closing tag for SVG element.
export const UserCircleIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z" fill={`url(#${iconGradientId})`}/>
        <path d="M12 6.5l.5 1 1 .5-1 .5-.5 1-.5-1-1-.5 1-.5.5-1z" fill="white"/>
    </svg>
);

export const BookIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 4h5v8l-2.5-1.5L6 12V4z" fill={`url(#${iconGradientId})`}/>
        <path d="M8 7l.5 1 1 .5-1 .5-.5 1-.5-1-1-.5 1-.5.5-1z" fill="white"/>
    </svg>
);

export const UniverseAICoreIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M12 2L9.19 8.63 2 11l7.19 2.37L12 21l2.81-7.63L22 11l-7.19-2.37L12 2z" fill={`url(#${iconGradientId})`}/>
    </svg>
);

export const CreativeMuseIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M9 21c0 .55.45 1 1 1h4c.55 0 1-.45 1-1v-1H9v1zm3-19C8.14 2 5 5.14 5 9c0 2.38 1.19 4.47 3 5.74V17c0 .55.45 1 1 1h4c.55 0 1-.45 1-1v-2.26c1.81-1.27 3-3.36 3-5.74 0-3.86-3.14-7-7-7z" fill={`url(#${iconGradientId})`}/>
        <path d="M12 4.5l.5 1 1 .5-1 .5-.5 1-.5-1-1-.5 1-.5.5-1z" fill="white"/>
        <path d="M8 8.5l.5 1 1 .5-1 .5-.5 1-.5-1-1-.5 1-.5.5-1z" fill="white"/>
        <path d="M16 8.5l.5 1 1 .5-1 .5-.5 1-.5-1-1-.5 1-.5.5-1z" fill="white"/>
    </svg>
);

export const MusicIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55c-2.21 0-4 1.79-4 4s1.79 4 4 4s4-1.79 4-4V7h4V3h-6z" fill={`url(#${iconGradientId})`}/>
        <path d="M10 15l.5 1 1 .5-1 .5-.5 1-.5-1-1-.5 1-.5.5-1z" fill="white"/>
    </svg>
);

export const SendIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
      <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
    </svg>
);

export const CheckCircleIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor">
    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
  </svg>
);

export const PaperclipIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
  </svg>
);

export const FileTextIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
  </svg>
);

export const MicrophoneIcon: React.FC<{isRecording?: boolean, isLive?: boolean}> = ({ isRecording, isLive }) => (
    isLive ? 
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.49 6-3.31 6-6.72h-1.7z" fill={`url(#${iconGradientId})`}/>
        <path d="M12 6.5l.5 1 1 .5-1 .5-.5 1-.5-1-1-.5 1-.5.5-1z" fill="white"/>
    </svg>
    :
    <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 ${isRecording ? 'text-red-500' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
    </svg>
);


export const PdfFileIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M10 21h7a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v11m0 5l4.879-4.879m0 0a3 3 0 104.242-4.242 3 3 0 00-4.242 4.242z" />
    </svg>
);

export const ToolsIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

export const WandIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <IconGradientDef />
        <path d="M13 3.05a.7.7 0 01.7.7v1.5a.7.7 0 01-.7.7h-2a.7.7 0 01-.7-.7v-1.5a.7.7 0 01.7-.7h2zM5.12 5.12a.7.7 0 01.99 0l1.06 1.06a.7.7 0 010 .99l-1.06 1.06a.7.7 0 01-.99 0l-1.06-1.06a.7.7 0 010-.99l1.06-1.06zM17.82 5.12a.7.7 0 01.99 0l1.06 1.06a.7.7 0 010 .99l-1.06 1.06a.7.7 0 01-.99 0l-1.06-1.06a.7.7 0 010-.99l1.06-1.06zM20.95 11h-1.5a.7.7 0 01-.7-.7v-2a.7.7 0 01.7-.7h1.5a.7.7 0 01.7.7v2a.7.7 0 01-.7.7zM3.05 11h1.5a.7.7 0 01.7.7v2a.7.7 0 01-.7.7h-1.5a.7.7 0 01-.7-.7v-2a.7.7 0 01.7-.7z" fill={`url(#${iconGradientId})`}/>
        <path d="M12 21.5l-1.9-1.9a1 1 0 010-1.41l7.07-7.07a1 1 0 000-1.41L15.31 7.8a1 1 0 00-1.41 0L6.83 14.87a1 1 0 01-1.41 0L3.5 13.04" stroke={`url(#${iconGradientId})`} strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M17.66 15.31L15.31 13" stroke={`url(#${iconGradientId})`} strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

export const Bars3Icon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
    </svg>
);

export const GlobeIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2h10a2 2 0 002-2v-1a2 2 0 012-2h1.945M7.704 4.122a.5.5 0 01.707 0l1.414 1.414a.5.5 0 010 .707l-1.414 1.414a.5.5 0 01-.707 0L7.704 5.539a.5.5 0 010-.707zM15.296 4.122a.5.5 0 01.707 0l1.414 1.414a.5.5 0 010 .707l-1.414 1.414a.5.5 0 01-.707 0l-1.414-1.414a.5.5 0 010-.707z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9 9 0 100-18 9 9 0 000 18z" />
    </svg>
);

export const ArrowPathIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
      <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0011.667 0l3.181-3.183m0 0v-4.992m0 0h-4.992m4.992 0l-3.181-3.183a8.25 8.25 0 00-11.667 0l-3.181 3.183" />
    </svg>
);