import React, { useState, useEffect, useRef, useCallback } from 'react';
import { CoreMessage, ContextFile, CognitiveState } from '../types';
import { universeCore_run, universeCore_executeTool, fileToBase64, fileToText, pdfToText } from '../services/geminiService';
import { UniverseAICoreIcon, SendIcon, UserCircleIcon, BrainIcon, PaperclipIcon, FileTextIcon, ImageIcon, MicrophoneIcon, PdfFileIcon, ToolsIcon, GlobeIcon, WandIcon, CheckCircleIcon } from './icons';
import { Chat, GenerateContentResponse, Part } from '@google/genai';
import { useNotification } from '../hooks/useNotification';

const getInitialState = <T,>(key: string, defaultValue: T): T => {
    try {
        const savedState = localStorage.getItem(key);
        return savedState ? JSON.parse(savedState) : defaultValue;
    } catch (error) {
        console.error(`Failed to parse ${key} from localStorage`, error);
        return defaultValue;
    }
};

const CognitiveMatrixPanel: React.FC<{
    cognitiveState: CognitiveState;
    uploadedFiles: ContextFile[];
    onRemoveFile: (fileName: string) => void;
}> = ({ cognitiveState, uploadedFiles, onRemoveFile }) => {

    const isIdle = cognitiveState.status === 'idle';

    const PanelContainer: React.FC<{title: string, icon: React.ReactNode, children: React.ReactNode}> = ({title, icon, children}) => (
         <div className="bg-gray-900/40 border border-purple-500/20 rounded-xl shadow-2xl shadow-purple-900/20 backdrop-blur-lg h-full flex flex-col">
            <h3 className="font-semibold text-center text-purple-400 p-3 flex items-center justify-center gap-2 border-b border-purple-500/20 flex-shrink-0">
                {icon}
                {title}
            </h3>
            <div className="overflow-y-auto p-3 space-y-3 flex-grow">{children}</div>
        </div>
    );

    if (isIdle) {
         return (
            <PanelContainer title="Context Hub" icon={<PaperclipIcon />}>
                {uploadedFiles.length === 0 ? (
                    <div className="flex-grow flex items-center justify-center text-center text-gray-500 text-sm p-4">
                        <p>Attach PDFs, text files, or images to provide context for your prompt.</p>
                    </div>
                ) : (
                    uploadedFiles.map(file => (
                        <div key={file.name} className="bg-gray-800/70 p-2 rounded-md flex items-center justify-between text-sm animate-fade-in">
                            <div className="flex items-center space-x-2 truncate">
                                <span className="text-purple-400 flex-shrink-0 h-6 w-6 flex items-center justify-center">{
                                    file.type === 'image' ? <ImageIcon /> :
                                    file.type === 'pdf' ? <PdfFileIcon /> :
                                    <FileTextIcon />
                                }</span>
                                <span className="text-gray-300 truncate">{file.name}</span>
                            </div>
                            <button onClick={() => onRemoveFile(file.name)} className="text-gray-500 hover:text-red-400 flex-shrink-0 text-xl font-bold px-2">&times;</button>
                        </div>
                    ))
                )}
            </PanelContainer>
        );
    }
    
    return (
        <PanelContainer title="Cognitive Matrix" icon={<BrainIcon />}>
            <div className="flex items-center space-x-2 text-sm p-2 bg-gray-800/50 rounded">
                <div className="flex-shrink-0 w-5 h-5 flex items-center justify-center text-purple-400"><BrainIcon /></div>
                <span className="flex-grow font-medium text-gray-300">Analyzing Prompt</span>
                <CheckCircleIcon />
            </div>
             {cognitiveState.status === 'tool_calling' && (
                <div className="p-2 bg-gray-800/50 rounded space-y-2">
                    <div className="flex items-center space-x-2 text-sm text-amber-300">
                        <div className="flex-shrink-0 w-5 h-5 flex items-center justify-center"><ToolsIcon /></div>
                        <span className="font-medium">Executing Tools</span>
                    </div>
                    {cognitiveState.activeTools.map((tool, index) => (
                         <div key={index} className="flex items-center space-x-2 text-sm pl-4">
                            <div className="flex-shrink-0 w-5 h-5 flex items-center justify-center">{tool.toolName === 'web_search' ? <GlobeIcon /> : <WandIcon />}</div>
                            <span className="flex-grow font-medium text-gray-400">{tool.toolName === 'web_search' ? `Searching for "${tool.args.query}"` : 'Generating Image...'}</span>
                             {tool.status === 'executing' ? (
                                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-400"></div>
                             ) : (
                                <CheckCircleIcon />
                            )}
                         </div>
                    ))}
                </div>
            )}
        </PanelContainer>
    );
};

const MessageBubble: React.FC<{ message: CoreMessage }> = ({ message }) => {
    const isUser = message.role === 'user';
    
    if (message.role === 'tool') {
        return (
            <div className="flex w-full max-w-3xl mx-auto items-center justify-center gap-3 text-sm my-2">
                <div className="flex items-center gap-2 px-3 py-1 bg-gray-800/80 border border-gray-700/80 rounded-full text-amber-300">
                    <ToolsIcon />
                    <span>Tool Executed: <span className="font-semibold text-amber-200">{message.toolResponse?.name}</span></span>
                    <CheckCircleIcon />
                </div>
            </div>
        )
    }
    
    const bubbleContent = (
        <>
            {message.text && <p className="whitespace-pre-wrap break-words">{message.text}</p>}
            {message.imageContent && <img src={message.imageContent} alt="Generated content" className="mt-2 rounded-lg max-w-sm" />}
            {message.isError && <p className="text-red-300">{message.text}</p>}
        </>
    );

    const avatar = isUser ? (
        <div className="w-8 h-8 flex-shrink-0 rounded-full flex items-center justify-center bg-gray-600">
            <UserCircleIcon />
        </div>
    ) : (
        <div className="w-8 h-8 flex-shrink-0 rounded-full flex items-center justify-center bg-gray-900 border border-gray-700">
            <UniverseAICoreIcon />
        </div>
    );

    const bubbleClasses = isUser
        ? 'bg-gradient-to-br from-purple-600 to-indigo-600 rounded-bl-none'
        : 'bg-gray-700/80 rounded-br-none';

    return (
        <div className="flex items-start gap-3">
            {!isUser && avatar}
            <div className={`px-4 py-3 rounded-xl max-w-full md:max-w-md lg:max-w-lg shadow-md text-gray-100 ${bubbleClasses}`}>
                {bubbleContent}
            </div>
            {isUser && avatar}
        </div>
    );
};

const ChatHistoryPanel: React.FC<{ history: CoreMessage[], onSelect: (prompt: string, files: ContextFile[]) => void }> = ({ history, onSelect }) => {
    const userHistory = history.filter(m => m.role === 'user').reverse();
    return (
        <div className="bg-gray-900/40 border border-purple-500/20 rounded-xl shadow-2xl shadow-purple-900/20 backdrop-blur-lg h-full flex flex-col">
            <h3 className="font-semibold text-center text-purple-400 p-3 border-b border-purple-500/20 flex-shrink-0">Session History</h3>
            <div className="space-y-1 overflow-y-auto p-2">
                {userHistory.map((msg) => (
                    <button 
                        key={msg.id}
                        onClick={() => onSelect(msg.text || '', msg.contextFiles || [])}
                        className="w-full text-left p-2 rounded-md bg-gray-800/70 hover:bg-gray-700/80 transition-colors truncate text-sm text-gray-300"
                    >
                       {msg.text}
                    </button>
                ))}
            </div>
        </div>
    );
}

const UniverseAICore: React.FC = () => {
    const [history, setHistory] = useState<CoreMessage[]>(() => getInitialState('universe_history_v8', []));
    const [prompt, setPrompt] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [uploadedFiles, setUploadedFiles] = useState<ContextFile[]>([]);
    const [isRecording, setIsRecording] = useState(false);
    const [cognitiveState, setCognitiveState] = useState<CognitiveState>({ status: 'idle', activeTools: [] });
    
    const messagesEndRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const recognitionRef = useRef<any>(null); // SpeechRecognition
    const chatSessionRef = useRef<Chat | null>(null);
    const addNotification = useNotification();

    useEffect(() => {
        localStorage.setItem('universe_history_v8', JSON.stringify(history));
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [history]);

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        if (!files) return;

        try {
            const newFilesPromises = Array.from(files).map(async (file: File) => {
                if (uploadedFiles.some(upFile => upFile.name === file.name)) return null;
                const type = file.type.startsWith('image/') ? 'image' : (file.type === 'application/pdf' ? 'pdf' : 'text');
                const content = type === 'image' ? await fileToBase64(file) : (type === 'pdf' ? await pdfToText(file) : await fileToText(file));
                return { name: file.name, type, mimeType: file.type, content };
            });
            const newFiles = (await Promise.all(newFilesPromises)).filter(f => f !== null) as ContextFile[];
            setUploadedFiles(prev => [...prev, ...newFiles]);
            addNotification(`${newFiles.length} file(s) added to context.`, 'success');
        } catch (err) {
            console.error("Error processing files:", err);
            addNotification('Error processing one or more files.', 'error');
        } finally {
            if(fileInputRef.current) fileInputRef.current.value = "";
        }
    };
    
    const toggleRecording = () => {
        if (isRecording) {
            recognitionRef.current?.stop();
            setIsRecording(false);
            return;
        }
        const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
        if (!SpeechRecognition) {
            addNotification("Speech recognition is not supported in this browser.", 'error');
            return;
        }
        recognitionRef.current = new SpeechRecognition();
        recognitionRef.current.continuous = true;
        recognitionRef.current.interimResults = true;
        recognitionRef.current.onresult = (event: any) => {
            let interimTranscript = '';
            for (let i = event.resultIndex; i < event.results.length; ++i) {
                if (event.results[i].isFinal) {
                    setPrompt(prev => prev + event.results[i][0].transcript);
                } else {
                    interimTranscript += event.results[i][0].transcript;
                }
            }
        };
        recognitionRef.current.start();
        setIsRecording(true);
    };

    const processStream = useCallback(async (streamPromise: Promise<AsyncGenerator<GenerateContentResponse>>) => {
        const stream = await streamPromise;
        let fullResponse: CoreMessage = { id: (Date.now() + 1).toString(), role: 'model', text: '', toolCalls: [] };
        let text = '';
        
        setHistory(prev => [...prev, fullResponse]);
        
        for await (const chunk of stream) {
            text += chunk.text;
            fullResponse = { ...fullResponse, text };
            
            if (chunk.functionCalls && chunk.functionCalls.length > 0) {
                 fullResponse = { ...fullResponse, toolCalls: chunk.functionCalls };
            }

            setHistory(prev => {
                const newHistory = [...prev];
                newHistory[newHistory.length - 1] = fullResponse;
                return newHistory;
            });
        }
        return fullResponse;
    }, []);

    const handleSubmit = async (currentPrompt: string) => {
        if (!currentPrompt.trim() || isLoading) return;

        setIsLoading(true);
        const userMessage: CoreMessage = { id: Date.now().toString(), role: 'user', text: currentPrompt, contextFiles: uploadedFiles };
        setHistory(prev => [...prev, userMessage]);
        setCognitiveState({ status: 'analyzing', activeTools: [] });

        setPrompt('');
        setUploadedFiles([]);

        try {
            const { chat, streamPromise } = universeCore_run(currentPrompt, userMessage.contextFiles || []);
            chatSessionRef.current = chat;
            let modelResponse = await processStream(streamPromise);

            while (modelResponse.toolCalls && modelResponse.toolCalls.length > 0) {
                const toolCalls = modelResponse.toolCalls;
                 setCognitiveState({
                    status: 'tool_calling',
                    activeTools: toolCalls.map(tc => ({ toolName: tc.name as any, args: tc.args, status: 'executing' })),
                 });

                const toolResponses = await Promise.all(toolCalls.map(async (tc) => {
                    const result = await universeCore_executeTool(tc.name, tc.args);
                    return { id: tc.id, name: tc.name, response: result };
                }));
                
                setCognitiveState(prev => ({ ...prev, activeTools: prev.activeTools.map(t => ({ ...t, status: 'complete' }))}));

                toolResponses.forEach(tr => {
                    setHistory(prev => [...prev, { id: Date.now().toString(), role: 'tool', toolResponse: tr }]);
                });
                
                if (chatSessionRef.current) {
                    const toolResponseParts: Part[] = toolResponses.map(tr => ({
                        toolResponse: {
                            id: tr.id,
                            name: tr.name,
                            response: tr.response,
                        },
                    }));

                    const continueStreamPromise = chatSessionRef.current.sendMessageStream({
                        message: toolResponseParts
                    });
                    modelResponse = await processStream(Promise.resolve(continueStreamPromise));
                }
            }

        } catch (err) {
            console.error(err);
            addNotification('An unexpected error occurred.', 'error');
            setHistory(prev => [...prev, { id: Date.now().toString(), role: 'model', text: 'An error occurred. Please try again.', isError: true }]);
        } finally {
            setIsLoading(false);
            setCognitiveState({ status: 'idle', activeTools: [] });
        }
    };
    
    return (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 h-full bg-transparent font-sans p-4">
            <div className="hidden lg:block lg:col-span-3 h-full">
                <ChatHistoryPanel history={history} onSelect={(p, f) => { setPrompt(p); setUploadedFiles(f); }} />
            </div>

            <div className="lg:col-span-6 h-full flex flex-col bg-gray-900/40 border border-purple-500/20 rounded-xl shadow-2xl shadow-purple-900/20 backdrop-blur-lg">
                <div className="p-3 border-b border-purple-500/20 flex items-center justify-center space-x-2 shrink-0">
                    <div className="w-6 h-6"><UniverseAICoreIcon /></div>
                    <h2 className="text-lg font-semibold text-center text-gray-200">UniverseAI Core</h2>
                </div>
                <div className="flex-1 p-4 md:p-6 overflow-y-auto space-y-6">
                    {history.length === 0 && (
                        <div className="text-center text-gray-500 pt-16 flex flex-col items-center">
                            <div className="w-16 h-16 mb-4"><UniverseAICoreIcon /></div>
                            <h3 className="text-xl font-semibold">Welcome to the Core</h3>
                            <p>Speak, type, or attach files to begin.</p>
                        </div>
                    )}
                    {history.map((msg) => (
                        <div key={msg.id} className={`flex w-full items-start ${msg.role === 'tool' ? 'justify-center' : (msg.role === 'user' ? 'justify-end' : 'justify-start')}`}>
                            <MessageBubble message={msg} />
                        </div>
                    ))}
                    {isLoading && cognitiveState.status === 'responding' && <div className="flex justify-start"><MessageBubble message={{ id: 'thinking', role: 'model', text: '...'}} /></div>}

                    <div ref={messagesEndRef} />
                </div>
                <div className="p-3 border-t border-purple-500/20 shrink-0">
                    <form onSubmit={(e) => { e.preventDefault(); handleSubmit(prompt); }}>
                        <div className="flex items-center p-1 bg-gray-900/70 rounded-lg border border-gray-600 focus-within:ring-2 focus-within:ring-purple-500 transition-all duration-200 shadow-inner">
                            <button type="button" onClick={() => fileInputRef.current?.click()} className="text-gray-400 hover:text-purple-400 p-2 rounded-md" aria-label="Attach file" disabled={isLoading}>
                                <PaperclipIcon />
                            </button>
                             <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" multiple accept="image/*,.txt,.md,.pdf" />
                            <button type="button" onClick={toggleRecording} className="text-gray-400 hover:text-purple-400 p-2 rounded-md" aria-label="Use microphone" disabled={isLoading}>
                                <MicrophoneIcon isRecording={isRecording} />
                            </button>
                            <input type="text" value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Engage the UniverseAI Core..." className="flex-1 bg-transparent text-gray-200 px-3 py-2 focus:outline-none placeholder-gray-500" disabled={isLoading}/>
                            <button type="submit" className="bg-purple-600 text-white p-2 rounded-md hover:bg-purple-700 transition-colors disabled:bg-gray-600 disabled:cursor-not-allowed" disabled={isLoading || !prompt.trim()} aria-label="Send message">
                               <SendIcon />
                            </button>
                        </div>
                    </form>
                </div>
            </div>

             <div className="hidden lg:block lg:col-span-3 h-full">
                <CognitiveMatrixPanel 
                    cognitiveState={cognitiveState}
                    uploadedFiles={uploadedFiles}
                    onRemoveFile={(fileName) => setUploadedFiles(files => files.filter(f => f.name !== fileName))}
                />
             </div>
        </div>
    );
};

export default UniverseAICore;