
import React, { useState, useEffect, useCallback } from 'react';
import { generateVideo, pollVideoOperation, blobToDataURL, fileToDataURL, dataURLtoFile } from '../services/geminiService';
import { LoadingState } from '../types';
import LoadingSpinner from './common/LoadingSpinner';
import ApiKeyDialog from './common/ApiKeyDialog';
import Card from './ui/Card';
import ResetButton from './common/ResetButton';
import { useNotification } from '../hooks/useNotification';
import Button from './ui/Button';

const aspectRatios = ['16:9', '9:16'] as const;
type AspectRatio = typeof aspectRatios[number];

const videoModels = [
    { id: 'veo-3.1-fast-generate-preview', name: 'Veo 3.1 Fast' },
    { id: 'veo-3.1-generate-preview', name: 'Veo 3.1 High Quality' },
];

const loadingMessages = [
    "Warming up the digital director's chair...",
    "Choreographing pixels into motion...",
    "Rendering your cinematic masterpiece...",
    "Adding a touch of Hollywood magic...",
    "Finalizing the cuts, almost showtime!",
];

const VideoGenerator: React.FC = () => {
    const [prompt, setPrompt] = useState(() => localStorage.getItem('videoGen_prompt') || '');
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [aspectRatio, setAspectRatio] = useState<AspectRatio>(() => (localStorage.getItem('videoGen_aspectRatio') as AspectRatio) || '16:9');
    const [selectedModel, setSelectedModel] = useState(() => localStorage.getItem('videoGen_model') || videoModels[0].id);
    const [videoUrl, setVideoUrl] = useState<string | null>(() => localStorage.getItem('videoGen_videoUrl') || null);
    const [loading, setLoading] = useState<LoadingState>('idle');
    const [error, setError] = useState<string | null>(null);
    const [apiKeySelected, setApiKeySelected] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState(loadingMessages[0]);
    const addNotification = useNotification();
    
    // Load initial state from localStorage
    useEffect(() => {
        const savedImage = localStorage.getItem('videoGen_imageDataUrl');
        if (savedImage) {
            setImageUrl(savedImage);
            const file = dataURLtoFile(savedImage, 'uploaded-image');
            if (file) {
                setImageFile(file);
            }
        }
    }, []);

    useEffect(() => { localStorage.setItem('videoGen_prompt', prompt); }, [prompt]);
    useEffect(() => { localStorage.setItem('videoGen_aspectRatio', aspectRatio); }, [aspectRatio]);
    useEffect(() => { localStorage.setItem('videoGen_model', selectedModel); }, [selectedModel]);
    useEffect(() => {
        if (videoUrl) {
            localStorage.setItem('videoGen_videoUrl', videoUrl);
        } else {
            localStorage.removeItem('videoGen_videoUrl');
        }
    }, [videoUrl]);
    
    const checkApiKey = useCallback(async () => {
        // @ts-ignore
        if (window.aistudio && await window.aistudio.hasSelectedApiKey()) {
            setApiKeySelected(true);
        } else {
            setApiKeySelected(false);
        }
    }, []);

    useEffect(() => {
        checkApiKey();
        const interval = setInterval(checkApiKey, 2000); // Periodically check in case the dialog is slow
        return () => clearInterval(interval);
    }, [checkApiKey]);

    useEffect(() => {
        let interval: number;
        if (loading === 'loading') {
            interval = window.setInterval(() => {
                setLoadingMessage(prev => {
                    const currentIndex = loadingMessages.indexOf(prev);
                    return loadingMessages[(currentIndex + 1) % loadingMessages.length];
                });
            }, 3000);
        }
        return () => window.clearInterval(interval);
    }, [loading]);

    const handleSelectKey = async () => {
        // @ts-ignore
        if (window.aistudio) {
            // @ts-ignore
            await window.aistudio.openSelectKey();
            // Assume success after opening dialog to avoid race condition
            setApiKeySelected(true); 
        }
    };

    const handleReset = () => {
        setPrompt('');
        setImageFile(null);
        setImageUrl(null);
        setAspectRatio('16:9');
        setSelectedModel(videoModels[0].id);
        setVideoUrl(null);
        setLoading('idle');
        setError(null);
        localStorage.removeItem('videoGen_prompt');
        localStorage.removeItem('videoGen_imageDataUrl');
        localStorage.removeItem('videoGen_aspectRatio');
        localStorage.removeItem('videoGen_model');
        localStorage.removeItem('videoGen_videoUrl');
        addNotification('Video Generator reset.', 'info');
    };
    
    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setImageFile(file);
            const dataUrl = await fileToDataURL(file);
            setImageUrl(dataUrl);
            localStorage.setItem('videoGen_imageDataUrl', dataUrl);
        } else {
            setImageFile(null);
            setImageUrl(null);
            localStorage.removeItem('videoGen_imageDataUrl');
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!prompt.trim() && !imageFile) {
            setError("A text prompt or an initial image is required.");
            return;
        }

        setLoading('loading');
        setVideoUrl(null);
        setError(null);
        setLoadingMessage(loadingMessages[0]);

        try {
            let operation = await generateVideo(prompt, imageFile, aspectRatio, selectedModel);
            while (!operation.done) {
                await new Promise(resolve => setTimeout(resolve, 10000)); // Poll every 10s
                operation = await pollVideoOperation(operation);
            }

            if (operation.response?.generatedVideos?.[0]?.video?.uri) {
                const downloadLink = operation.response.generatedVideos[0].video.uri;
                const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
                const blob = await response.blob();
                const dataUrl = await blobToDataURL(blob);
                setVideoUrl(dataUrl);
                setLoading('success');
            } else {
                throw new Error("Video generation completed, but no video URI was found.");
            }

        } catch (err: any) {
            console.error(err);
            let errorMessage = 'Failed to generate video. Please try again.';
            if (err.message?.includes("Requested entity was not found")) {
                errorMessage = "API Key not found or invalid. Please select a valid API key.";
                setApiKeySelected(false);
            }
            setError(errorMessage);
            setLoading('error');
        }
    };

    if (!apiKeySelected) {
        return <ApiKeyDialog onSelectKey={handleSelectKey} />;
    }

    return (
        <div className="max-w-4xl mx-auto animate-fade-in">
            <Card
                title="Video Generation with Veo"
                description="Create dynamic videos from text prompts or by animating an initial image."
                actions={<ResetButton onReset={handleReset} />}
            >
                <form onSubmit={handleSubmit} className="space-y-4">
                     <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">Model</label>
                        <div className="flex flex-wrap gap-2">
                            {videoModels.map(model => (
                                <Button
                                    key={model.id}
                                    type="button"
                                    variant={selectedModel === model.id ? 'primary' : 'secondary'}
                                    onClick={() => setSelectedModel(model.id)}
                                >
                                    {model.name}
                                </Button>
                            ))}
                        </div>
                    </div>
                    <div>
                        <label htmlFor="prompt" className="block text-sm font-medium text-gray-300 mb-1">Prompt (optional if image is provided)</label>
                        <textarea
                            id="prompt"
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="e.g., A neon hologram of a cat driving at top speed through a futuristic city"
                            className="w-full bg-gray-900/50 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500 min-h-[80px]"
                        />
                    </div>
                     <div>
                        <label htmlFor="image-upload" className="block text-sm font-medium text-gray-300 mb-1">Initial Image (optional)</label>
                        <input
                            id="image-upload"
                            type="file"
                            accept="image/*"
                            onChange={handleFileChange}
                            className="w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-purple-600 file:text-white hover:file:bg-purple-700"
                        />
                    </div>
                    {imageUrl && <img src={imageUrl} alt="Initial frame" className="rounded-lg shadow-lg mx-auto max-w-full max-h-60 mt-2" />}

                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">Aspect Ratio</label>
                        <div className="flex flex-wrap gap-2">
                            {aspectRatios.map(ar => (
                                <button
                                    key={ar}
                                    type="button"
                                    onClick={() => setAspectRatio(ar)}
                                    className={`px-4 py-2 rounded-md text-sm font-semibold transition-colors ${
                                        aspectRatio === ar ? 'bg-purple-600 text-white' : 'bg-gray-700 hover:bg-gray-600'
                                    }`}
                                >
                                    {ar === '16:9' ? '16:9 (Landscape)' : '9:16 (Portrait)'}
                                </button>
                            ))}
                        </div>
                    </div>

                    <button
                        type="submit"
                        className="w-full bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-700 transition-colors disabled:bg-gray-500"
                        disabled={loading === 'loading'}
                    >
                        {loading === 'loading' ? 'Generating...' : 'Generate Video'}
                    </button>
                </form>

                {loading === 'loading' && (
                    <div className="text-center p-4 space-y-4">
                        <div className="w-full bg-gray-700 rounded-full h-2.5 overflow-hidden">
                            <div className="bg-purple-600 h-2.5 rounded-full animate-pulse" style={{width: '100%', animation: 'indeterminate-progress 2s infinite ease-in-out'}}></div>
                        </div>
                        <p className="text-purple-300 animate-pulse">{loadingMessage}</p>
                        <p className="text-sm text-gray-400">Video generation can take a few minutes. Please be patient.</p>
                        <style>{`
                            @keyframes indeterminate-progress {
                                0% { transform: translateX(-100%); }
                                100% { transform: translateX(100%); }
                            }
                        `}</style>
                    </div>
                )}
                {error && <p className="text-red-400 text-center">{error}</p>}

                {videoUrl && (
                    <div className="mt-6">
                        <h3 className="text-lg font-semibold mb-2">Generated Video:</h3>
                        <video src={videoUrl} controls autoPlay loop className="rounded-lg shadow-lg w-full" />
                        <a href={videoUrl} download="generated-video.mp4" className="block text-center mt-4 text-purple-400 hover:underline">Download Video</a>
                    </div>
                )}
            </Card>
        </div>
    );
};

export default VideoGenerator;