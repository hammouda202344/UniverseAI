

import React, { useState, useEffect } from 'react';
import { editImage, fileToDataURL, dataURLtoFile } from '../services/geminiService';
import { LoadingState } from '../types';
import LoadingSpinner from './common/LoadingSpinner';
import Card from './ui/Card';
import Button from './ui/Button';
import { useNotification } from '../hooks/useNotification';
import ResetButton from './common/ResetButton';

const ImageEditor: React.FC = () => {
    const [prompt, setPrompt] = useState(() => localStorage.getItem('imageEditor_prompt') || '');
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [originalImageUrl, setOriginalImageUrl] = useState<string | null>(null);
    const [editedImageUrl, setEditedImageUrl] = useState<string | null>(() => localStorage.getItem('imageEditor_editedImageUrl') || null);
    const [loading, setLoading] = useState<LoadingState>('idle');
    const addNotification = useNotification();

    // Load initial state from localStorage
    useEffect(() => {
        const savedOriginalImage = localStorage.getItem('imageEditor_originalImageDataUrl');
        if (savedOriginalImage) {
            setOriginalImageUrl(savedOriginalImage);
            const file = dataURLtoFile(savedOriginalImage, 'uploaded-image');
            if (file) {
                setImageFile(file);
            }
        }
    }, []);

    useEffect(() => {
        localStorage.setItem('imageEditor_prompt', prompt);
    }, [prompt]);

    useEffect(() => {
        if (editedImageUrl) {
            localStorage.setItem('imageEditor_editedImageUrl', editedImageUrl);
        } else {
            localStorage.removeItem('imageEditor_editedImageUrl');
        }
    }, [editedImageUrl]);

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setImageFile(file);
            const dataUrl = await fileToDataURL(file);
            setOriginalImageUrl(dataUrl);
            localStorage.setItem('imageEditor_originalImageDataUrl', dataUrl);
            setEditedImageUrl(null);
            addNotification('Image uploaded successfully!', 'success');
        }
    };

    const handleReset = () => {
        setPrompt('');
        setImageFile(null);
        setOriginalImageUrl(null);
        setEditedImageUrl(null);
        setLoading('idle');
        localStorage.removeItem('imageEditor_prompt');
        localStorage.removeItem('imageEditor_originalImageDataUrl');
        localStorage.removeItem('imageEditor_editedImageUrl');
        addNotification('Image Editor reset.', 'info');
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!prompt.trim() || !imageFile) return;

        setLoading('loading');
        setEditedImageUrl(null);
        try {
            const resultUrl = await editImage(prompt, imageFile);
            setEditedImageUrl(resultUrl);
            setLoading('success');
            addNotification('Image edited successfully!', 'success');
        } catch (err: any) {
            console.error(err);
            addNotification(err.message || 'Failed to edit image. An unknown error occurred.', 'error');
            setLoading('error');
        }
    };

    return (
        <div className="max-w-4xl mx-auto animate-fade-in">
            <Card
                title="AI Image Editor"
                description="Upload an image and use a text prompt to magically edit it."
                actions={<ResetButton onReset={handleReset} />}
            >
                <div className="space-y-4">
                    <div>
                        <label htmlFor="image-upload" className="block text-sm font-medium text-gray-300 mb-1">Upload Image</label>
                        <input
                            id="image-upload"
                            type="file"
                            accept="image/*"
                            onChange={handleFileChange}
                            className="w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-gray-600 file:text-white hover:file:bg-gray-500"
                        />
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-4">
                        <textarea
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="e.g., Add a retro filter, or remove the person in the background"
                            className="w-full bg-gray-900/50 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500 min-h-[80px]"
                            required
                            disabled={!imageFile}
                        />
                         <p className="text-center text-xs text-gray-500 !-mt-2">
                            Powered by Gemini Flash Image
                        </p>
                        <Button
                            type="submit"
                            className="w-full"
                            disabled={loading === 'loading' || !prompt.trim() || !imageFile}
                        >
                            {loading === 'loading' ? 'Editing...' : 'Apply Edit'}
                        </Button>
                    </form>
                </div>
                
                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                    {originalImageUrl && (
                        <div>
                            <h3 className="text-lg font-semibold mb-2 text-center">Original</h3>
                            <img src={originalImageUrl} alt="Original" className="rounded-lg shadow-lg mx-auto max-w-full" />
                        </div>
                    )}
                     {loading === 'loading' && (
                        <div className="flex flex-col items-center justify-center h-full">
                            <h3 className="text-lg font-semibold mb-2 text-center">Edited</h3>
                            <div className="w-full aspect-square bg-gray-700/50 rounded-lg flex items-center justify-center">
                                <LoadingSpinner />
                            </div>
                        </div>
                     )}
                    {editedImageUrl && (
                         <div>
                            <h3 className="text-lg font-semibold mb-2 text-center">Edited</h3>
                            <img src={editedImageUrl} alt="Edited" className="rounded-lg shadow-lg mx-auto max-w-full" />
                            <a href={editedImageUrl} download="edited-image.png" className="block text-center mt-4 text-purple-400 hover:underline">Download Edited Image</a>
                        </div>
                    )}
                </div>
            </Card>
        </div>
    );
};

export default ImageEditor;