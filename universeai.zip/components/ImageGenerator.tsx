
import React, { useState, useEffect } from 'react';
import { generateImage, editImage, dataURLtoFile } from '../services/geminiService';
import { LoadingState } from '../types';
import LoadingSpinner from './common/LoadingSpinner';
import Card from './ui/Card';
import Button from './ui/Button';
import { useNotification } from '../hooks/useNotification';
import ResetButton from './common/ResetButton';
import { WandIcon } from './icons';

const aspectRatios = ["1:1", "16:9", "9:16", "4:3", "3:4"];
const imageModels = [
    { id: 'imagen-4.0-generate-001' as const, name: 'Imagen 4 (Highest Quality)' },
    { id: 'gemini-2.5-flash-image' as const, name: 'Nano Banana (Fast)' }
];

const ImageGenerator: React.FC = () => {
    const [prompt, setPrompt] = useState(() => localStorage.getItem('imageGen_prompt') || '');
    const [aspectRatio, setAspectRatio] = useState(() => localStorage.getItem('imageGen_aspectRatio') || "1:1");
    const [selectedModel, setSelectedModel] = useState<'imagen-4.0-generate-001' | 'gemini-2.5-flash-image'>(() => (localStorage.getItem('imageGen_model') as any) || imageModels[0].id);
    const [generatedImage, setGeneratedImage] = useState<string | null>(() => localStorage.getItem('imageGen_generatedImage') || null);
    const [loading, setLoading] = useState<LoadingState>('idle');
    const [refinePrompt, setRefinePrompt] = useState('');
    const [refining, setRefining] = useState(false);
    const addNotification = useNotification();

    useEffect(() => {
        localStorage.setItem('imageGen_prompt', prompt);
    }, [prompt]);

    useEffect(() => {
        localStorage.setItem('imageGen_aspectRatio', aspectRatio);
    }, [aspectRatio]);

    useEffect(() => {
        localStorage.setItem('imageGen_model', selectedModel);
    }, [selectedModel]);

    useEffect(() => {
        if (generatedImage) {
            localStorage.setItem('imageGen_generatedImage', generatedImage);
        } else {
            localStorage.removeItem('imageGen_generatedImage');
        }
    }, [generatedImage]);

    const handleReset = () => {
        setPrompt('');
        setAspectRatio('1:1');
        setSelectedModel(imageModels[0].id);
        setGeneratedImage(null);
        setLoading('idle');
        setRefinePrompt('');
        setRefining(false);
        localStorage.removeItem('imageGen_prompt');
        localStorage.removeItem('imageGen_aspectRatio');
        localStorage.removeItem('imageGen_model');
        localStorage.removeItem('imageGen_generatedImage');
        addNotification('Image Generator reset.', 'info');
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!prompt.trim()) return;

        setLoading('loading');
        setRefinePrompt('');
        setRefining(false);
        setGeneratedImage(null);
        try {
            const imageUrl = await generateImage(prompt, aspectRatio, selectedModel);
            setGeneratedImage(imageUrl);
            setLoading('success');
            addNotification('Image generated successfully!', 'success');
        } catch (err) {
            console.error(err);
            addNotification('Failed to generate image. Please try again.', 'error');
            setLoading('error');
        }
    };

    const handleRefine = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!refinePrompt.trim() || !generatedImage) return;

        setRefining(true);
        try {
            const imageFile = dataURLtoFile(generatedImage, 'generated-image-to-refine.png');
            if (!imageFile) {
                throw new Error("Could not prepare image for refinement.");
            }
            const refinedImageUrl = await editImage(refinePrompt, imageFile);
            setGeneratedImage(refinedImageUrl);
            addNotification('Image refined successfully!', 'success');
            setRefinePrompt('');
        } catch (err: any) {
            console.error(err);
            addNotification(err.message || 'Failed to refine image.', 'error');
        } finally {
            setRefining(false);
        }
    };

    return (
        <div className="max-w-4xl mx-auto animate-fade-in">
            <Card
                title="Iterative Image Generation"
                description="Create stunning images from text, then conversationally refine your creation until it's perfect."
                actions={<ResetButton onReset={handleReset} />}
            >
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">1. Select Model</label>
                        <div className="flex flex-wrap gap-2">
                            {imageModels.map(model => (
                                <Button
                                    key={model.id}
                                    type="button"
                                    variant={selectedModel === model.id ? 'primary' : 'secondary'}
                                    onClick={() => setSelectedModel(model.id)}
                                >
                                    {model.name}
                                </Button>
                            ))}
                        </div>
                    </div>
                    <div>
                        <label htmlFor="prompt" className="block text-sm font-medium text-gray-300 mb-1">2. Describe Your Image</label>
                        <textarea
                            id="prompt"
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="e.g., A cinematic shot of a robot holding a red skateboard in a futuristic city"
                            className="w-full bg-gray-900/50 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500 min-h-[80px]"
                            required
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">3. Choose Aspect Ratio</label>
                        <div className="flex flex-wrap gap-2">
                            {aspectRatios.map(ar => (
                                <Button
                                    key={ar}
                                    type="button"
                                    variant={aspectRatio === ar ? 'primary' : 'secondary'}
                                    onClick={() => setAspectRatio(ar)}
                                >
                                    {ar}
                                </Button>
                            ))}
                        </div>
                    </div>
                    <Button
                        type="submit"
                        className="w-full"
                        disabled={loading === 'loading' || refining}
                    >
                        {loading === 'loading' ? 'Generating...' : 'Generate Image'}
                    </Button>
                </form>

                {loading === 'loading' && <div className="mt-4"><LoadingSpinner /></div>}
                
                {generatedImage && (
                    <div className="mt-6 animate-fade-in">
                        <div className="relative">
                             <img src={generatedImage} alt="Generated from prompt" className="rounded-lg shadow-lg mx-auto max-w-full" />
                             {refining && (
                                <div className="absolute inset-0 bg-gray-900/70 rounded-lg flex items-center justify-center">
                                    <LoadingSpinner />
                                </div>
                             )}
                        </div>
                        <a href={generatedImage} download="generated-image.png" className="block text-center mt-4 text-purple-400 hover:underline">Download Image</a>
                         
                        <div className="mt-8 border-t border-gray-700/50 pt-6">
                            <h3 className="text-xl font-semibold mb-2 text-purple-300 flex items-center gap-2"><div className="w-5 h-5"><WandIcon/></div> 4. Refine Your Image</h3>
                            <p className="text-sm text-gray-400 mb-4">Describe the changes you'd like to make. This refinement step uses the powerful Nano Banana model for fast, in-place editing.</p>
                            <form onSubmit={handleRefine} className="space-y-4">
                                <textarea
                                    value={refinePrompt}
                                    onChange={(e) => setRefinePrompt(e.target.value)}
                                    placeholder="e.g., Change the skateboard to blue, add a cat in the background..."
                                    className="w-full bg-gray-900/50 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500 min-h-[80px]"
                                    required
                                    disabled={refining || loading === 'loading'}
                                />
                                <Button
                                    type="submit"
                                    className="w-full"
                                    disabled={refining || loading === 'loading' || !refinePrompt.trim()}
                                    variant="secondary"
                                >
                                    {refining ? 'Refining...' : 'Refine Image'}
                                </Button>
                            </form>
                        </div>
                    </div>
                )}
            </Card>
        </div>
    );
};

export default ImageGenerator;
