

import React from 'react';
import { Feature } from '../types';
import { UniverseAICoreIcon, ImageIcon, VideoIcon, EditIcon, EyeIcon, WandIcon, MicrophoneIcon, SearchIcon, SoundIcon, BookIcon, VideoEditIcon, ImageToVideoIcon, MusicIcon, AnimeIcon } from './icons';

interface HomeProps {
  setActiveFeature: (feature: Feature) => void;
}

const quickStartFeatures = [
  { id: Feature.UniverseAICore, icon: <UniverseAICoreIcon />, title: "UniverseAI Core", description: "The flagship multi-modal AI. Chat, analyze files, search the web, and generate images." },
  { id: Feature.ImageGeneration, icon: <ImageIcon />, title: "Image Generation", description: "Create stunning, high-quality images from a simple text description using Imagen 4." },
  { id: Feature.VideoGeneration, icon: <VideoIcon />, title: "Video Generation", description: "Generate dynamic videos from text prompts or by animating an initial image with Veo." },
];

const allFeatures = [
  { id: Feature.ImageEditing, icon: <EditIcon />, title: "Image Editing", description: "Upload an image and use a text prompt to magically edit it with AI." },
  { id: Feature.VideoEditing, icon: <VideoEditIcon />, title: "Video Editing", description: "Extend your videos by uploading one and describing what should happen next." },
  { id: Feature.ImageToVideo, icon: <ImageToVideoIcon />, title: "Image to Video", description: "Bring your static images to life by turning them into dynamic video clips." },
  { id: Feature.LiveConversation, icon: <MicrophoneIcon isLive />, title: "Live Conversation", description: "Talk with Gemini in real-time and get instant spoken responses." },
  { id: Feature.GroundingSearch, icon: <SearchIcon />, title: "Grounded Search", description: "Get up-to-date answers grounded in Google Search and Maps." },
  { id: Feature.TextToSpeech, icon: <SoundIcon />, title: "Text to Speech", description: "Convert text into natural-sounding speech with a variety of voice avatars." },
  { id: Feature.EbookGeneration, icon: <BookIcon />, title: "Ebook Generation", description: "Generate a complete, multi-chapter ebook from a single topic prompt." },
  { id: Feature.AnimeProductionStudio, icon: <AnimeIcon />, title: "Anime Production Studio", description: "A professional workflow to design characters, create storyboards, and animate scenes." },
  { id: Feature.ImageAnalysis, icon: <EyeIcon />, title: "Image Analysis", description: "Upload an image and ask complex questions to understand its content." },
  { id: Feature.VideoAnalysis, icon: <WandIcon />, title: "Video Analysis", description: "Upload a video to get a detailed, AI-powered analysis of its contents." },
  { id: Feature.LyriaAI, icon: <MusicIcon />, title: "Lyria AI", description: "Generate vocal melodies and instrumental concepts with an AI designed for music creation." },
];

const FeatureCard: React.FC<{feature: typeof allFeatures[0], onClick: () => void, isLarge?: boolean}> = ({ feature, onClick, isLarge = false }) => {
    return (
        <div 
            onClick={onClick}
            className={`bg-gray-900/40 border border-purple-500/20 rounded-xl p-6 flex flex-col items-start hover:bg-gray-800/60 hover:border-purple-500/50 transition-all duration-300 cursor-pointer shadow-2xl shadow-purple-900/20 backdrop-blur-lg transform hover:-translate-y-1`}
        >
            <div className="p-3 bg-gray-900/50 rounded-lg border border-gray-700/80 mb-4">
                <div className="w-6 h-6">{feature.icon}</div>
            </div>
            <h3 className={`${isLarge ? 'text-2xl' : 'text-xl'} font-semibold text-gray-100 mb-2`}>{feature.title}</h3>
            <p className="text-gray-400 text-sm flex-grow">{feature.description}</p>
        </div>
    );
};

const Home: React.FC<HomeProps> = ({ setActiveFeature }) => {
  return (
    <div className="animate-fade-in space-y-12">
        <div className="text-center p-8 bg-gray-900/40 border border-purple-500/20 rounded-xl shadow-2xl shadow-purple-900/20 backdrop-blur-lg">
             <div className="w-16 h-16 mx-auto mb-4"><UniverseAICoreIcon/></div>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-100">Welcome to <span className="bg-clip-text text-transparent bg-gradient-to-r from-violet-400 to-indigo-500">AI Studio Pro</span></h1>
            <p className="mt-3 text-lg text-gray-300 max-w-2xl mx-auto">Your all-in-one suite for content creation, powered by Gemini. Select a tool below to begin your next project.</p>
        </div>

        <div>
            <h2 className="text-2xl font-bold text-gray-200 mb-6 px-2">Quick Start</h2>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {quickStartFeatures.map(feature => (
                    <FeatureCard 
                        key={feature.id} 
                        feature={feature} 
                        onClick={() => setActiveFeature(feature.id)}
                        isLarge
                    />
                ))}
            </div>
        </div>

        <div>
            <h2 className="text-2xl font-bold text-gray-200 mb-6 px-2">Full Toolbox</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {allFeatures.map(feature => (
                    <FeatureCard 
                        key={feature.id} 
                        feature={feature} 
                        onClick={() => setActiveFeature(feature.id)}
                    />
                ))}
            </div>
        </div>
    </div>
  );
};

export default Home;