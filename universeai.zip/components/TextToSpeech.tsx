
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { textToSpeech, decode, decodeAudioData } from '../services/geminiService';
import { LoadingState } from '../types';
import LoadingSpinner from './common/LoadingSpinner';
import Card from './ui/Card';
import ResetButton from './common/ResetButton';
import { useNotification } from '../hooks/useNotification';

const voiceGroups = {
    "Afrikaans": [
        { name: 'Anika', value: 'af-ZA-Standard-A' }, { name: 'Ruben', value: 'af-ZA-Standard-B' }, { name: 'Zola', value: 'af-ZA-Standard-C' }, { name: 'Pieter', value: 'af-ZA-Standard-D' },
    ],
    "Amharic": [
        { name: 'Abeba', value: 'am-ET-Standard-A' }, { name: 'Dawit', value: 'am-ET-Standard-B' }, { name: 'Hana', value: 'am-ET-Standard-C' }, { name: 'Yosef', value: 'am-ET-Standard-D' },
    ],
    "Arabic (Modern Standard)": [
        { name: 'Amir', value: 'ar-XA-Wavenet-A' }, { name: 'Fatima', value: 'ar-XA-Wavenet-B' }, { name: 'Omar', value: 'ar-XA-Wavenet-C' }, { name: 'Layla', value: 'ar-XA-Wavenet-D' },
    ],
    "Azerbaijani": [
        { name: 'Ayla', value: 'az-AZ-Standard-A' }, { name: 'Rashad', value: 'az-AZ-Standard-B' }, { name: 'Nigar', value: 'az-AZ-Standard-C' }, { name: 'Elchin', value: 'az-AZ-Standard-D' },
    ],
    "Basque": [
        { name: 'Ane', value: 'eu-ES-Standard-A' }, { name: 'Iker', value: 'eu-ES-Standard-B' }, { name: 'Leire', value: 'eu-ES-Standard-C' }, { name: 'Mikel', value: 'eu-ES-Standard-D' },
    ],
    "Bengali (India)": [
        { name: 'Ananya', value: 'bn-IN-Wavenet-A' }, { name: 'Rohan', value: 'bn-IN-Wavenet-B' }, { name: 'Ishita', value: 'bn-IN-Wavenet-C' }, { name: 'Vikram', value: 'bn-IN-Wavenet-D' },
    ],
    "Bulgarian": [
        { name: 'Elena', value: 'bg-BG-Standard-A' }, { name: 'Dimitar', value: 'bg-BG-Standard-B' }, { name: 'Maria', value: 'bg-BG-Standard-C' }, { name: 'Georgi', value: 'bg-BG-Standard-D' },
    ],
    "Burmese": [
        { name: 'Aung', value: 'my-MM-Standard-A' }, { name: 'Thida', value: 'my-MM-Standard-B' }, { name: 'Kyaw', value: 'my-MM-Standard-C' }, { name: 'Su', value: 'my-MM-Standard-D' },
    ],
    "Catalan": [
        { name: 'Laia', value: 'ca-ES-Standard-A' }, { name: 'Marc', value: 'ca-ES-Standard-B' }, { name: 'Clara', value: 'ca-ES-Standard-C' }, { name: 'Pau', value: 'ca-ES-Standard-D' },
    ],
    "Chinese (Mandarin, Mainland)": [
        { name: 'Li Na', value: 'cmn-CN-Wavenet-A' }, { name: 'Wang Wei', value: 'cmn-CN-Wavenet-B' }, { name: 'Zhang Wei', value: 'cmn-CN-Wavenet-C' }, { name: 'Liu Ying', value: 'cmn-CN-Wavenet-D' }, { name: 'Sun Yue', value: 'cmn-CN-Standard-A' }, { name: 'Gao Feng', value: 'cmn-CN-Standard-B' },
    ],
    "Chinese (Mandarin, Taiwan)": [
        { name: 'Chen Mei', value: 'cmn-TW-Wavenet-A' }, { name: 'Lin Yi', value: 'cmn-TW-Wavenet-B' }, { name: 'Huang Li', value: 'cmn-TW-Wavenet-C' }, { name: 'Wu De', value: 'cmn-TW-Wavenet-D' },
    ],
    "Czech": [
        { name: 'Eva', value: 'cs-CZ-Wavenet-A' }, { name: 'Jan', value: 'cs-CZ-Wavenet-B' }, { name: 'Lucie', value: 'cs-CZ-Wavenet-C' }, { name: 'Tomáš', value: 'cs-CZ-Wavenet-D' },
    ],
    "Danish": [
        { name: 'Freja', value: 'da-DK-Wavenet-A' }, { name: 'William', value: 'da-DK-Wavenet-C' }, { name: 'Ida', value: 'da-DK-Wavenet-D' }, { name: 'Noah', value: 'da-DK-Wavenet-E' },
    ],
    "Dutch": [
        { name: 'Emma', value: 'nl-NL-Wavenet-A' }, { name: 'Daan', value: 'nl-NL-Wavenet-B' }, { name: 'Sophie', value: 'nl-NL-Wavenet-C' }, { name: 'Lucas', value: 'nl-NL-Wavenet-D' }, { name: 'Lotte', value: 'nl-NL-Wavenet-E' },
    ],
    "English (Australia)": [
        { name: 'Jack', value: 'en-AU-Wavenet-A' }, { name: 'Charlotte', value: 'en-AU-Wavenet-B' }, { name: 'Noah', value: 'en-AU-Wavenet-C' }, { name: 'Isla', value: 'en-AU-Wavenet-D' },
    ],
    "English (India)": [
        { name: 'Aisha', value: 'en-IN-Wavenet-A' }, { name: 'Kabir', value: 'en-IN-Wavenet-B' }, { name: 'Ravi', value: 'en-IN-Wavenet-C' }, { name: 'Priya', value: 'en-IN-Wavenet-D' },
    ],
    "English (UK)": [
        { name: 'Arthur', value: 'en-GB-Wavenet-A' }, { name: 'Eleanor', value: 'en-GB-Wavenet-B' }, { name: 'George', value: 'en-GB-Wavenet-C' }, { name: 'Beatrice', value: 'en-GB-Wavenet-D' }, { name: 'Oliver', value: 'en-GB-Wavenet-F' },
    ],
    "English (US)": [
        { name: 'Aether', value: 'Aether' }, { name: 'Boreas', value: 'Boreas' }, { name: 'Charon', value: 'Charon' }, { name: 'Cinder', value: 'Cinder' }, { name: 'Cryptex', value: 'Cryptex' }, { name: 'Dusk', value: 'Dusk' }, { name: 'Elara', value: 'Elara' }, { name: 'Eos', value: 'Eos' }, { name: 'Fenrir', value: 'Fenrir' }, { name: 'Gale', value: 'Gale' }, { name: 'Hades', value: 'Hades' }, { name: 'Jinx', value: 'Jinx' }, { name: 'Kai', value: 'Kai' }, { name: 'Kore', value: 'Kore' }, { name: 'Loki', value: 'Loki' }, { name: 'Lyra', value: 'Lyra' }, { name: 'Nyx', value: 'Nyx' }, { name: 'Orion', value: 'Orion' }, { name: 'Puck', value: 'Puck' }, { name: 'Rhea', value: 'Rhea' }, { name: 'Sol', value: 'Sol' }, { name: 'Styx', value: 'Styx' }, { name: 'Tartarus', value: 'Tartarus' }, { name: 'Umbra', value: 'Umbra' }, { name: 'Vex', value: 'Vex' }, { name: 'Vulcan', value: 'Vulcan' }, { name: 'Zephyr', value: 'Zephyr' }, { name: 'Zeta', value: 'Zeta' },
        { name: 'Jacob', value: 'en-US-Wavenet-A' }, { name: 'Noah', value: 'en-US-Wavenet-B' }, { name: 'Emily', value: 'en-US-Wavenet-C' }, { name: 'Michael', value: 'en-US-Wavenet-D' }, { name: 'Emma', value: 'en-US-Wavenet-E' }, { name: 'Ava', value: 'en-US-Wavenet-F' }, { name: 'Mia', value: 'en-US-Wavenet-G' }, { name: 'Sophia', value: 'en-US-Wavenet-H' }, { name: 'William', value: 'en-US-Wavenet-I' }, { name: 'James', value: 'en-US-Wavenet-J' },
    ],
    "Estonian": [
        { name: 'Liisi', value: 'et-EE-Standard-A' }, { name: 'Marek', value: 'et-EE-Standard-B' }, { name: 'Kadri', value: 'et-EE-Standard-C' }, { name: 'Sander', value: 'et-EE-Standard-D' },
    ],
    "Finnish": [
        { name: 'Sofia', value: 'fi-FI-Wavenet-A' }, { name: 'Leo', value: 'fi-FI-Wavenet-B' }, { name: 'Aino', value: 'fi-FI-Wavenet-C' }, { name: 'Elias', value: 'fi-FI-Wavenet-D' },
    ],
    "French (Canada)": [
        { name: 'Emilie', value: 'fr-CA-Wavenet-A' }, { name: 'Felix', value: 'fr-CA-Wavenet-B' }, { name: 'Alice', value: 'fr-CA-Wavenet-C' }, { name: 'Leo', value: 'fr-CA-Wavenet-D' },
    ],
    "French (France)": [
        { name: 'Juliette', value: 'fr-FR-Wavenet-A' }, { name: 'Lucas', value: 'fr-FR-Wavenet-B' }, { name: 'Manon', value: 'fr-FR-Wavenet-C' }, { name: 'Louis', value: 'fr-FR-Wavenet-D' }, { name: 'Chloé', value: 'fr-FR-Wavenet-E' }, { name: 'Hugo', value: 'fr-FR-Wavenet-F' }, { name: 'Léa', value: 'fr-FR-Wavenet-G' },
    ],
    "Galician": [
        { name: 'Noa', value: 'gl-ES-Standard-A' }, { name: 'Hugo', value: 'gl-ES-Standard-B' }, { name: 'Sofia', value: 'gl-ES-Standard-C' }, { name: 'Mateo', value: 'gl-ES-Standard-D' },
    ],
    "Georgian": [
        { name: 'Nino', value: 'ka-GE-Standard-A' }, { name: 'Giorgi', value: 'ka-GE-Standard-B' }, { name: 'Mariam', value: 'ka-GE-Standard-C' }, { name: 'Davit', value: 'ka-GE-Standard-D' },
    ],
    "German": [
        { name: 'Lena', value: 'de-DE-Wavenet-A' }, { name: 'Felix', value: 'de-DE-Wavenet-B' }, { name: 'Anna', value: 'de-DE-Wavenet-C' }, { name: 'Jonas', value: 'de-DE-Wavenet-D' }, { name: 'Mia', value: 'de-DE-Wavenet-F' }, { name: 'Paul', value: 'de-DE-Wavenet-E' }, { name: 'Hanna', value: 'de-DE-Wavenet-G' }, { name: 'Klara', value: 'de-DE-Wavenet-H' }, { name: 'Lukas', value: 'de-DE-Wavenet-I' }, { name: 'Max', value: 'de-DE-Wavenet-J' },
    ],
    "Greek": [
        { name: 'Eleni', value: 'el-GR-Wavenet-A' }, { name: 'Nikos', value: 'el-GR-Wavenet-B' }, { name: 'Sofia', value: 'el-GR-Wavenet-C' }, { name: 'Giorgos', value: 'el-GR-Wavenet-D' },
    ],
    "Gujarati (India)": [
        { name: 'Diya', value: 'gu-IN-Wavenet-A' }, { name: 'Aarav', value: 'gu-IN-Wavenet-B' }, { name: 'Isha', value: 'gu-IN-Wavenet-C' }, { name: 'Rohan', value: 'gu-IN-Wavenet-D' },
    ],
    "Hebrew": [
        { name: 'Tamar', value: 'he-IL-Wavenet-A' }, { name: 'Ido', value: 'he-IL-Wavenet-B' }, { name: 'Noa', value: 'he-IL-Wavenet-C' }, { name: 'Ariel', value: 'he-IL-Wavenet-D' },
    ],
    "Hindi": [
        { name: 'Aditi', value: 'hi-IN-Wavenet-A' }, { name: 'Rohan', value: 'hi-IN-Wavenet-B' }, { name: 'Priya', value: 'hi-IN-Wavenet-C' }, { name: 'Arjun', value: 'hi-IN-Wavenet-D' },
    ],
    "Hungarian": [
        { name: 'Anna', value: 'hu-HU-Wavenet-A' }, { name: 'Bence', value: 'hu-HU-Wavenet-B' }, { name: 'Zsófia', value: 'hu-HU-Wavenet-C' }, { name: 'Levente', value: 'hu-HU-Wavenet-D' },
    ],
    "Icelandic": [
        { name: 'Guðrún', value: 'is-IS-Standard-A' }, { name: 'Jón', value: 'is-IS-Standard-B' }, { name: 'Anna', value: 'is-IS-Standard-C' }, { name: 'Gunnar', value: 'is-IS-Standard-D' },
    ],
    "Indonesian": [
        { name: 'Budi', value: 'id-ID-Wavenet-A' }, { name: 'Citra', value: 'id-ID-Wavenet-B' }, { name: 'Dian', value: 'id-ID-Wavenet-C' }, { name: 'Eko', value: 'id-ID-Wavenet-D' },
    ],
    "Italian": [
        { name: 'Sofia', value: 'it-IT-Wavenet-A' }, { name: 'Leonardo', value: 'it-IT-Wavenet-B' }, { name: 'Giulia', value: 'it-IT-Wavenet-C' }, { name: 'Francesco', value: 'it-IT-Wavenet-D' }, { name: 'Chiara', value: 'it-IT-Wavenet-E' }, { name: 'Alessandro', value: 'it-IT-Wavenet-F' },
    ],
    "Japanese": [
        { name: 'Hana', value: 'ja-JP-Wavenet-A' }, { name: 'Kenji', value: 'ja-JP-Wavenet-B' }, { name: 'Yuki', value: 'ja-JP-Wavenet-C' }, { name: 'Ren', value: 'ja-JP-Wavenet-D' }, { name: 'Sakura', value: 'ja-JP-Wavenet-E' }, { name: 'Haruto', value: 'ja-JP-Wavenet-F' }, { name: 'Rin', value: 'ja-JP-Wavenet-G' }, { name: 'Sota', value: 'ja-JP-Wavenet-H' }, { name: 'Yui', value: 'ja-JP-Wavenet-I' },
    ],
    "Javanese": [
        { name: 'Sari', value: 'jv-ID-Standard-A' }, { name: 'Budi', value: 'jv-ID-Standard-B' }, { name: 'Dewi', value: 'jv-ID-Standard-C' }, { name: 'Joko', value: 'jv-ID-Standard-D' },
    ],
    "Kannada (India)": [
        { name: 'Ananya', value: 'kn-IN-Wavenet-A' }, { name: 'Vihaan', value: 'kn-IN-Wavenet-B' }, { name: 'Saanvi', value: 'kn-IN-Wavenet-C' }, { name: 'Advik', value: 'kn-IN-Wavenet-D' },
    ],
    "Khmer": [
        { name: 'Sophea', value: 'km-KH-Standard-A' }, { name: 'Vibol', value: 'km-KH-Standard-B' }, { name: 'Bopha', value: 'km-KH-Standard-C' }, { name: 'Rithy', value: 'km-KH-Standard-D' },
    ],
    "Korean": [
        { name: 'Min-jun', value: 'ko-KR-Wavenet-A' }, { name: 'Seo-yeon', value: 'ko-KR-Wavenet-B' }, { name: 'Ji-hoon', value: 'ko-KR-Wavenet-C' }, { name: 'Soo-jin', value: 'ko-KR-Wavenet-D' },
    ],
    "Lao": [
        { name: 'Chansouk', value: 'lo-LA-Standard-A' }, { name: 'Somchai', value: 'lo-LA-Standard-B' }, { name: 'Mali', value: 'lo-LA-Standard-C' }, { name: 'Thong', value: 'lo-LA-Standard-D' },
    ],
    "Latvian": [
        { name: 'Jānis', value: 'lv-LV-Standard-A' }, { name: 'Līga', value: 'lv-LV-Standard-B' }, { name: 'Māris', value: 'lv-LV-Standard-C' }, { name: 'Kristīne', value: 'lv-LV-Standard-D' },
    ],
    "Lithuanian": [
        { name: 'Jonas', value: 'lt-LT-Standard-A' }, { name: 'Lina', value: 'lt-LT-Standard-B' }, { name: 'Tomas', value: 'lt-LT-Standard-C' }, { name: 'Ieva', value: 'lt-LT-Standard-D' },
    ],
    "Malay": [
        { name: 'Ahmad', value: 'ms-MY-Wavenet-A' }, { name: 'Siti', value: 'ms-MY-Wavenet-B' }, { name: 'Zul', value: 'ms-MY-Wavenet-C' }, { name: 'Nur', value: 'ms-MY-Wavenet-D' },
    ],
    "Malayalam (India)": [
        { name: 'Lakshmi', value: 'ml-IN-Wavenet-A' }, { name: 'Arjun', value: 'ml-IN-Wavenet-B' }, { name: 'Meera', value: 'ml-IN-Wavenet-C' }, { name: 'Rahul', value: 'ml-IN-Wavenet-D' },
    ],
    "Mongolian": [
        { name: 'Batbayar', value: 'mn-MN-Standard-A' }, { name: 'Oyuna', value: 'mn-MN-Standard-B' }, { name: 'Temuujin', value: 'mn-MN-Standard-C' }, { name: 'Solongo', value: 'mn-MN-Standard-D' },
    ],
    "Nepali": [
        { name: 'Sunita', value: 'ne-NP-Standard-A' }, { name: 'Ramesh', value: 'ne-NP-Standard-B' }, { name: 'Sabina', value: 'ne-NP-Standard-C' }, { name: 'Hari', value: 'ne-NP-Standard-D' },
    ],
    "Norwegian (Bokmål)": [
        { name: 'Ingrid', value: 'nb-NO-Wavenet-A' }, { name: 'Henrik', value: 'nb-NO-Wavenet-B' }, { name: 'Solveig', value: 'nb-NO-Wavenet-C' }, { name: 'Magnus', value: 'nb-NO-Wavenet-D' }, { name: 'Astrid', value: 'nb-NO-Wavenet-E' },
    ],
    "Polish": [
        { name: 'Zofia', value: 'pl-PL-Wavenet-A' }, { name: 'Jakub', value: 'pl-PL-Wavenet-B' }, { name: 'Maja', value: 'pl-PL-Wavenet-C' }, { name: 'Antoni', value: 'pl-PL-Wavenet-D' }, { name: 'Ewa', value: 'pl-PL-Wavenet-E' },
    ],
    "Portuguese (Brazil)": [
        { name: 'Sofia', value: 'pt-BR-Wavenet-A' }, { name: 'Miguel', value: 'pt-BR-Wavenet-B' }, { name: 'Julia', value: 'pt-BR-Wavenet-C' }, { name: 'Arthur', value: 'pt-BR-Wavenet-D' },
    ],
    "Portuguese (Portugal)": [
        { name: 'Beatriz', value: 'pt-PT-Wavenet-A' }, { name: 'Diogo', value: 'pt-PT-Wavenet-B' }, { name: 'Ines', value: 'pt-PT-Wavenet-C' }, { name: 'Tiago', value: 'pt-PT-Wavenet-D' },
    ],
    "Romanian": [
        { name: 'Elena', value: 'ro-RO-Wavenet-A' }, { name: 'Andrei', value: 'ro-RO-Wavenet-B' }, { name: 'Ioana', value: 'ro-RO-Wavenet-C' }, { name: 'Mihai', value: 'ro-RO-Wavenet-D' },
    ],
    "Russian": [
        { name: 'Anastasia', value: 'ru-RU-Wavenet-A' }, { name: 'Dmitry', value: 'ru-RU-Wavenet-B' }, { name: 'Ekaterina', value: 'ru-RU-Wavenet-C' }, { name: 'Ivan', value: 'ru-RU-Wavenet-D' }, { name: 'Maria', value: 'ru-RU-Wavenet-E' },
    ],
    "Serbian": [
        { name: 'Milica', value: 'sr-RS-Standard-A' }, { name: 'Nikola', value: 'sr-RS-Standard-B' }, { name: 'Jelena', value: 'sr-RS-Standard-C' }, { name: 'Marko', value: 'sr-RS-Standard-D' },
    ],
    "Sinhala": [
        { name: 'Nimali', value: 'si-LK-Standard-A' }, { name: 'Kasun', value: 'si-LK-Standard-B' }, { name: 'Dilini', value: 'si-LK-Standard-C' }, { name: 'Sameera', value: 'si-LK-Standard-D' },
    ],
    "Slovak": [
        { name: 'Zuzana', value: 'sk-SK-Wavenet-A' }, { name: 'Martin', value: 'sk-SK-Wavenet-B' }, { name: 'Katarína', value: 'sk-SK-Wavenet-C' }, { name: 'Jozef', value: 'sk-SK-Wavenet-D' },
    ],
    "Slovenian": [
        { name: 'Luka', value: 'sl-SI-Standard-A' }, { name: 'Ana', value: 'sl-SI-Standard-B' }, { name: 'Jan', value: 'sl-SI-Standard-C' }, { name: 'Maja', value: 'sl-SI-Standard-D' },
    ],
    "Spanish (Mexico)": [
        { name: 'Sofia', value: 'es-MX-Wavenet-A' }, { name: 'Santiago', value: 'es-MX-Wavenet-B' }, { name: 'Valentina', value: 'es-MX-Wavenet-C' }, { name: 'Diego', value: 'es-MX-Wavenet-D' },
    ],
    "Spanish (Spain)": [
        { name: 'Mateo', value: 'es-ES-Wavenet-A' }, { name: 'Lucia', value: 'es-ES-Wavenet-B' }, { name: 'Hugo', value: 'es-ES-Wavenet-C' }, { name: 'Sofia', value: 'es-ES-Wavenet-D' }, { name: 'Daniel', value: 'es-ES-Wavenet-E' }, { name: 'Paula', value: 'es-ES-Wavenet-F' },
    ],
    "Spanish (US)": [
        { name: 'Camila', value: 'es-US-Wavenet-A' }, { name: 'Santiago', value: 'es-US-Wavenet-B' }, { name: 'Isabella', value: 'es-US-Wavenet-C' }, { name: 'Mateo', value: 'es-US-Wavenet-D' },
    ],
    "Sundanese": [
        { name: 'Nani', value: 'su-ID-Standard-A' }, { name: 'Asep', value: 'su-ID-Standard-B' }, { name: 'Siti', value: 'su-ID-Standard-C' }, { name: 'Ujang', value: 'su-ID-Standard-D' },
    ],
    "Swahili": [
        { name: 'Asha', value: 'sw-KE-Standard-A' }, { name: 'Juma', value: 'sw-KE-Standard-B' }, { name: 'Zuri', value: 'sw-KE-Standard-C' }, { name: 'Baraka', value: 'sw-KE-Standard-D' },
    ],
    "Swedish": [
        { name: 'Alice', value: 'sv-SE-Wavenet-A' }, { name: 'William', value: 'sv-SE-Wavenet-B' }, { name: 'Elsa', value: 'sv-SE-Wavenet-C' }, { name: 'Hugo', value: 'sv-SE-Wavenet-D' }, { name: 'Vera', value: 'sv-SE-Wavenet-E' },
    ],
    "Tagalog (Filipino)": [
        { name: 'Juan', value: 'fil-PH-Wavenet-A' }, { name: 'Maria', value: 'fil-PH-Wavenet-B' }, { name: 'Jose', value: 'fil-PH-Wavenet-C' }, { name: 'Clara', value: 'fil-PH-Wavenet-D' },
    ],
    "Tamil (India)": [
        { name: 'Anjali', value: 'ta-IN-Wavenet-A' }, { name: 'Arun', value: 'ta-IN-Wavenet-B' }, { name: 'Kavya', value: 'ta-IN-Wavenet-C' }, { name: 'Vikram', value: 'ta-IN-Wavenet-D' },
    ],
    "Telugu (India)": [
        { name: 'Sita', value: 'te-IN-Standard-A' }, { name: 'Ram', value: 'te-IN-Standard-B' }, { name: 'Lakshmi', value: 'te-IN-Standard-C' }, { name: 'Arjun', value: 'te-IN-Standard-D' },
    ],
    "Thai": [
        { name: 'Pim', value: 'th-TH-Standard-A' }, { name: 'Lek', value: 'th-TH-Standard-B' }, { name: 'Dao', value: 'th-TH-Standard-C' }, { name: 'Artit', value: 'th-TH-Standard-D' },
    ],
    "Tunisian Arabic": [
        { name: 'Youssef', value: 'ar-XA-Wavenet-A' }, { name: 'Amina', value: 'ar-XA-Wavenet-B' }, { name: 'Omar', value: 'ar-XA-Wavenet-C' }, { name: 'Layla', value: 'ar-XA-Wavenet-D' }
    ],
    "Turkish": [
        { name: 'Zeynep', value: 'tr-TR-Wavenet-A' }, { name: 'Emre', value: 'tr-TR-Wavenet-B' }, { name: 'Elif', value: 'tr-TR-Wavenet-C' }, { name: 'Can', value: 'tr-TR-Wavenet-D' }, { name: 'Ayse', value: 'tr-TR-Wavenet-E' },
    ],
    "Ukrainian": [
        { name: 'Sofia', value: 'uk-UA-Wavenet-A' }, { name: 'Andriy', value: 'uk-UA-Wavenet-B' }, { name: 'Yana', value: 'uk-UA-Wavenet-C' }, { name: 'Oleksandr', value: 'uk-UA-Wavenet-D' },
    ],
    "Urdu (Pakistan)": [
        { name: 'Ayesha', value: 'ur-PK-Wavenet-A' }, { name: 'Ali', value: 'ur-PK-Wavenet-B' }, { name: 'Fatima', value: 'ur-PK-Wavenet-C' }, { name: 'Ahmed', value: 'ur-PK-Wavenet-D' },
    ],
    "Uzbek": [
        { name: 'Lola', value: 'uz-UZ-Standard-A' }, { name: 'Aziz', value: 'uz-UZ-Standard-B' }, { name: 'Madina', value: 'uz-UZ-Standard-C' }, { name: 'Sardor', value: 'uz-UZ-Standard-D' },
    ],
    "Vietnamese": [
        { name: 'Linh', value: 'vi-VN-Wavenet-A' }, { name: 'An', value: 'vi-VN-Wavenet-B' }, { name: 'Bao', value: 'vi-VN-Wavenet-C' }, { name: 'Chi', value: 'vi-VN-Wavenet-D' },
    ],
    "Zulu": [
        { name: 'Thandiwe', value: 'zu-ZA-Standard-A' }, { name: 'Sipho', value: 'zu-ZA-Standard-B' }, { name: 'Jabulani', value: 'zu-ZA-Standard-C' }, { name: 'Mandla', value: 'zu-ZA-Standard-D' },
    ],
};

const stringToColor = (str: string) => {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    let color = '#';
    for (let i = 0; i < 3; i++) {
        const value = (hash >> (i * 8)) & 0xFF;
        color += ('00' + value.toString(16)).substr(-2);
    }
    return color;
};

const getInitials = (name: string) => {
    const parts = name.split(' ');
    if (parts.length > 1) {
        return parts[0][0] + parts[parts.length - 1][0];
    }
    return name[0];
};

const TextToSpeech: React.FC = () => {
    const [text, setText] = useState(() => localStorage.getItem('tts_text') || '');
    const [selectedVoice, setSelectedVoice] = useState(() => localStorage.getItem('tts_selectedVoice') || voiceGroups["English (US)"][0].value);
    const [loading, setLoading] = useState<LoadingState>('idle');
    const [isPlaying, setIsPlaying] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const audioContextRef = useRef<AudioContext | null>(null);
    const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);
    const addNotification = useNotification();

    useEffect(() => {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        return () => {
            audioContextRef.current?.close();
        };
    }, []);

    useEffect(() => {
        localStorage.setItem('tts_text', text);
    }, [text]);

    useEffect(() => {
        localStorage.setItem('tts_selectedVoice', selectedVoice);
    }, [selectedVoice]);

    const avatarDetails = useMemo(() => {
        for (const [language, voices] of Object.entries(voiceGroups)) {
            const voice = voices.find(v => v.value === selectedVoice);
            if (voice) {
                const combinedString = `${voice.name}-${language}`;
                return {
                    name: voice.name,
                    language: language,
                    initials: getInitials(voice.name),
                    color: stringToColor(combinedString),
                }
            }
        }
        return { name: 'Unknown', language: 'Unknown', initials: '?', color: '#808080' };
    }, [selectedVoice]);

    const handleReset = () => {
        setText('');
        setSelectedVoice(voiceGroups["English (US)"][0].value);
        setLoading('idle');
        setError(null);
        setIsPlaying(false);
        if (audioSourceRef.current) {
            audioSourceRef.current.stop();
        }
        localStorage.removeItem('tts_text');
        localStorage.removeItem('tts_selectedVoice');
        addNotification('Text-to-Speech reset.', 'info');
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!text.trim()) return;

        setLoading('loading');
        setError(null);
        setIsPlaying(false);

        if (audioSourceRef.current) {
            audioSourceRef.current.stop();
            audioSourceRef.current.onended = null;
        }

        try {
            const base64Audio = await textToSpeech(text, selectedVoice);
            if (base64Audio && audioContextRef.current) {
                const audioBuffer = await decodeAudioData(decode(base64Audio), audioContextRef.current, 24000, 1);
                const source = audioContextRef.current.createBufferSource();
                source.buffer = audioBuffer;
                source.connect(audioContextRef.current.destination);
                
                source.onended = () => {
                    setIsPlaying(false);
                    audioSourceRef.current = null;
                };

                source.start();
                setIsPlaying(true);
                audioSourceRef.current = source;
            } else {
                 throw new Error("No audio data received.");
            }
            setLoading('success');
        } catch (err) {
            console.error(err);
            setError('Failed to generate speech. Please try again.');
            setLoading('error');
            setIsPlaying(false);
        }
    };

    return (
        <div className="max-w-4xl mx-auto animate-fade-in">
            <Card
                title="Text-to-Speech with Voice Avatars"
                description="Convert text into natural speech and see a unique avatar for each voice."
                actions={<ResetButton onReset={handleReset} />}
            >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                    <form onSubmit={handleSubmit} className="space-y-4">
                         <div>
                            <label htmlFor="voice-select" className="block text-sm font-medium text-gray-300 mb-1">Voice</label>
                            <select
                                id="voice-select"
                                value={selectedVoice}
                                onChange={(e) => setSelectedVoice(e.target.value)}
                                className="w-full bg-gray-900/50 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
                            >
                                {Object.entries(voiceGroups).map(([groupName, voices]) => (
                                    <optgroup label={groupName} key={groupName}>
                                        {voices.map(voice => (
                                            <option key={voice.value} value={voice.value}>{voice.name}</option>
                                        ))}
                                    </optgroup>
                                ))}
                            </select>
                        </div>
                        <textarea
                            value={text}
                            onChange={(e) => setText(e.target.value)}
                            placeholder="Enter text to convert to speech. You can add instructions like 'Say cheerfully: ...'"
                            className="w-full bg-gray-900/50 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500 min-h-[150px]"
                            required
                        />
                        <button
                            type="submit"
                            className="w-full bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-700 transition-colors disabled:bg-gray-500"
                            disabled={loading === 'loading' || !text.trim()}
                        >
                            {loading === 'loading' ? 'Generating...' : (isPlaying ? 'Playing...' : 'Generate & Play Speech')}
                        </button>
                        {loading === 'loading' && <div className="text-center pt-2"><LoadingSpinner /></div>}
                        {error && <p className="text-red-400 text-center pt-2">{error}</p>}
                    </form>
                    
                    <div className="flex flex-col items-center justify-center p-4">
                        <div 
                            className={`relative w-48 h-48 rounded-full flex items-center justify-center text-white text-6xl font-bold transition-all duration-300 ease-in-out ${isPlaying ? 'animate-pulse' : ''}`}
                            style={{ 
                                backgroundColor: avatarDetails.color,
                                boxShadow: isPlaying 
                                    ? `0 0 25px ${avatarDetails.color}, 0 0 50px ${avatarDetails.color}aa` 
                                    : '0 10px 15px -3px rgba(0,0,0,0.3), 0 4px 6px -2px rgba(0,0,0,0.2)',
                                transform: isPlaying ? 'scale(1.05)' : 'scale(1)',
                            }}
                        >
                           <div 
                             className="absolute inset-0 rounded-full" 
                             style={{ background: 'radial-gradient(circle at 50% 30%, rgba(255,255,255,0.4), rgba(255,255,255,0) 70%)' }}
                           />
                            <span className="z-10 tracking-wider">{avatarDetails.initials}</span>
                        </div>
                        <p className="mt-4 text-2xl font-bold text-gray-100">{avatarDetails.name}</p>
                        <p className="text-md text-gray-400">{avatarDetails.language}</p>
                    </div>
                </div>
            </Card>
        </div>
    );
};

export default TextToSpeech;