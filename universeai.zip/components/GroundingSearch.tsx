
import React, { useState, useEffect } from 'react';
import { groundedSearch } from '../services/geminiService';
import { LoadingState, GroundingChunk } from '../types';
import LoadingSpinner from './common/LoadingSpinner';
import Card from './ui/Card';
import ResetButton from './common/ResetButton';
import { useNotification } from '../hooks/useNotification';

const getInitialState = <T,>(key: string, defaultValue: T): T => {
    try {
        const savedState = localStorage.getItem(key);
        if (savedState === null || savedState === 'undefined') return defaultValue;
        return JSON.parse(savedState);
    } catch (error) {
        console.error(`Failed to parse ${key} from localStorage`, error);
        return defaultValue;
    }
};

const GroundingSearch: React.FC = () => {
    const [query, setQuery] = useState(() => localStorage.getItem('grounding_query') || '');
    const [useMaps, setUseMaps] = useState(() => getInitialState('grounding_useMaps', false));
    const [location, setLocation] = useState<GeolocationCoordinates | null>(null);
    const [locationError, setLocationError] = useState<string | null>(null);
    const [result, setResult] = useState<string | null>(() => localStorage.getItem('grounding_result') || null);
    const [chunks, setChunks] = useState<GroundingChunk[]>(() => getInitialState('grounding_chunks', []));
    const [loading, setLoading] = useState<LoadingState>('idle');
    const [error, setError] = useState<string | null>(null);
    const addNotification = useNotification();

    useEffect(() => {
        if (useMaps && !location) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    setLocation(position.coords);
                    setLocationError(null);
                },
                (err) => {
                    setLocationError("Could not get location. Please enable location services in your browser.");
                    setUseMaps(false);
                }
            );
        }
    }, [useMaps, location]);

    useEffect(() => {
        localStorage.setItem('grounding_query', query);
    }, [query]);

    useEffect(() => {
        localStorage.setItem('grounding_useMaps', JSON.stringify(useMaps));
    }, [useMaps]);

    useEffect(() => {
        if (result) {
            localStorage.setItem('grounding_result', result);
        } else {
            localStorage.removeItem('grounding_result');
        }
    }, [result]);

    useEffect(() => {
        localStorage.setItem('grounding_chunks', JSON.stringify(chunks));
    }, [chunks]);

    const handleReset = () => {
        setQuery('');
        setUseMaps(false);
        setResult(null);
        setChunks([]);
        setLoading('idle');
        setError(null);
        localStorage.removeItem('grounding_query');
        localStorage.removeItem('grounding_useMaps');
        localStorage.removeItem('grounding_result');
        localStorage.removeItem('grounding_chunks');
        addNotification('Grounded Search reset.', 'info');
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!query.trim()) return;

        setLoading('loading');
        setResult(null);
        setChunks([]);
        setError(null);
        try {
            const { text, chunks } = await groundedSearch(query, useMaps, location);
            setResult(text);
            setChunks(chunks);
            setLoading('success');
        } catch (err) {
            console.error(err);
            setError('Failed to perform search. Please try again.');
            setLoading('error');
        }
    };

    return (
        <div className="max-w-4xl mx-auto animate-fade-in">
            <Card
                title="Grounded Search"
                description="Ask questions that require up-to-date information or location-based context. The model uses Google Search and Maps to provide accurate answers."
                actions={<ResetButton onReset={handleReset} />}
            >
                <form onSubmit={handleSubmit} className="space-y-4">
                    <textarea
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        placeholder="e.g., Who won the latest F1 race? or What are some good cafes near me?"
                        className="w-full bg-gray-900/50 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500 min-h-[80px]"
                        required
                    />
                    <div className="flex items-center">
                        <input
                            type="checkbox"
                            id="use-maps"
                            checked={useMaps}
                            onChange={(e) => setUseMaps(e.target.checked)}
                            className="h-4 w-4 rounded border-gray-300 text-purple-600 focus:ring-purple-500"
                        />
                        <label htmlFor="use-maps" className="ml-2 block text-sm text-gray-300">
                            Use Google Maps for location-based results
                        </label>
                    </div>
                    {locationError && <p className="text-yellow-400 text-sm">{locationError}</p>}
                    <button
                        type="submit"
                        className="w-full bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-700 transition-colors disabled:bg-gray-500"
                        disabled={loading === 'loading'}
                    >
                        {loading === 'loading' ? 'Searching...' : 'Search'}
                    </button>
                </form>

                {loading === 'loading' && <div className="mt-4"><LoadingSpinner /></div>}
                {error && <p className="text-red-400 text-center">{error}</p>}

                {result && (
                    <div className="mt-6 p-4 bg-gray-900/50 rounded-lg space-y-4">
                        <div>
                            <h3 className="text-lg font-semibold mb-2 text-purple-300">Answer:</h3>
                            <p className="whitespace-pre-wrap text-gray-200">{result}</p>
                        </div>
                        {chunks.length > 0 && (
                            <div>
                                <h3 className="text-lg font-semibold mb-2 text-purple-300">Sources:</h3>
                                <ul className="list-disc list-inside space-y-1">
                                    {chunks.map((chunk, index) => (
                                        <li key={index}>
                                            {chunk.web?.uri && <a href={chunk.web.uri} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">{chunk.web.title || chunk.web.uri}</a>}
                                            {chunk.maps?.uri && <a href={chunk.maps.uri} target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">{chunk.maps.title || chunk.maps.uri}</a>}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </div>
                )}
            </Card>
        </div>
    );
};

export default GroundingSearch;