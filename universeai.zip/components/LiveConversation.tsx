import React, { useState, useRef, useEffect, useCallback } from 'react';
import { createLiveSession, decode, decodeAudioData, encode } from '../services/geminiService';
import { LiveServerMessage, Blob } from '@google/genai';
import Card from './ui/Card';
import { MicrophoneIcon, UserCircleIcon, UniverseAICoreIcon } from './icons';

type ConnectionState = 'idle' | 'connecting' | 'connected' | 'error' | 'closed';

const getInitialState = <T,>(key: string, defaultValue: T): T => {
    try {
        const savedState = localStorage.getItem(key);
        if (savedState === null || savedState === 'undefined') return defaultValue;
        return JSON.parse(savedState);
    } catch (error) {
        console.error(`Failed to parse ${key} from localStorage`, error);
        return defaultValue;
    }
};

const LiveConversation: React.FC = () => {
    const [connectionState, setConnectionState] = useState<ConnectionState>('idle');
    const [transcriptions, setTranscriptions] = useState<{user: string, model: string}[]>(() => getInitialState('live_transcriptions_v2', []));
    const [currentTranscription, setCurrentTranscription] = useState({ user: '', model: '' });

    const sessionPromiseRef = useRef<ReturnType<typeof createLiveSession> | null>(null);
    const mediaStreamRef = useRef<MediaStream | null>(null);
    const audioContextRef = useRef<AudioContext | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
    const outputAudioContextRef = useRef<AudioContext | null>(null);
    const nextStartTimeRef = useRef<number>(0);
    const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
    const transcriptEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        localStorage.setItem('live_transcriptions_v2', JSON.stringify(transcriptions));
        transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [transcriptions]);

    useEffect(() => {
        transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [currentTranscription]);

    const cleanup = useCallback(() => {
        sessionPromiseRef.current?.then(session => session.close());
        mediaStreamRef.current?.getTracks().forEach(track => track.stop());
        scriptProcessorRef.current?.disconnect();
        sourceRef.current?.disconnect();
        audioContextRef.current?.close();
        outputAudioContextRef.current?.close();
        
        sessionPromiseRef.current = null;
        mediaStreamRef.current = null;
        audioContextRef.current = null;
        scriptProcessorRef.current = null;
        sourceRef.current = null;
        outputAudioContextRef.current = null;
        nextStartTimeRef.current = 0;
        sourcesRef.current.clear();

        setConnectionState('closed');
    }, []);

    const startConversation = async () => {
        if (connectionState === 'connected' || connectionState === 'connecting') return;
        setConnectionState('connecting');
        setCurrentTranscription({ user: '', model: '' });

        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaStreamRef.current = stream;

            const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
            audioContextRef.current = inputAudioContext;
            
            const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            outputAudioContextRef.current = outputAudioContext;

            const sessionPromise = createLiveSession({
                onopen: () => {
                    setConnectionState('connected');
                    const source = inputAudioContext.createMediaStreamSource(stream);
                    sourceRef.current = source;
                    const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);
                    scriptProcessorRef.current = scriptProcessor;
                    
                    scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                        const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                        const pcmBlob: Blob = {
                            data: encode(new Uint8Array(new Int16Array(inputData.map(x => x * 32768)).buffer)),
                            mimeType: 'audio/pcm;rate=16000',
                        };
                        sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob }));
                    };
                    source.connect(scriptProcessor);
                    scriptProcessor.connect(inputAudioContext.destination);
                },
                onmessage: async (message: LiveServerMessage) => {
                    let userText = '';
                    let modelText = '';

                    if (message.serverContent?.outputTranscription) {
                        modelText = message.serverContent.outputTranscription.text;
                    }
                    if (message.serverContent?.inputTranscription) {
                        userText = message.serverContent.inputTranscription.text;
                    }

                    setCurrentTranscription(prev => ({ user: prev.user + userText, model: prev.model + modelText }));

                    if (message.serverContent?.turnComplete) {
                        setCurrentTranscription(prev => {
                            if (prev.user || prev.model) {
                                setTranscriptions(history => [...history, prev]);
                            }
                            return { user: '', model: ''};
                        });
                    }
                    
                    const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData.data;
                    if (base64Audio) {
                        nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContext.currentTime);
                        const audioBuffer = await decodeAudioData(decode(base64Audio), outputAudioContext, 24000, 1);
                        const sourceNode = outputAudioContext.createBufferSource();
                        sourceNode.buffer = audioBuffer;
                        sourceNode.connect(outputAudioContext.destination);
                        sourceNode.addEventListener('ended', () => sourcesRef.current.delete(sourceNode));
                        sourceNode.start(nextStartTimeRef.current);
                        nextStartTimeRef.current += audioBuffer.duration;
                        sourcesRef.current.add(sourceNode);
                    }
                },
                onerror: (e: ErrorEvent) => {
                    console.error('Live session error:', e);
                    setConnectionState('error');
                    cleanup();
                },
                onclose: () => {
                    cleanup();
                },
            });
            sessionPromiseRef.current = sessionPromise;

        } catch (error) {
            console.error('Failed to start conversation:', error);
            setConnectionState('error');
        }
    };
    
    useEffect(() => {
        return () => cleanup();
    // eslint-disable-next-line react-hooks-exhaustive-deps
    }, []);

    const stopConversation = () => {
        cleanup();
    };

    const isConversationActive = connectionState === 'connected' || connectionState === 'connecting';

    const renderTranscription = (text: string, role: 'user' | 'model', isCurrent: boolean) => {
        const avatar = role === 'user' ? (
            <div className="w-8 h-8 flex-shrink-0 rounded-full flex items-center justify-center bg-gray-600">
                <UserCircleIcon />
            </div>
        ) : (
            <div className="w-8 h-8 flex-shrink-0 rounded-full flex items-center justify-center bg-gray-900 border border-gray-700">
                <UniverseAICoreIcon />
            </div>
        );

        const bubbleClasses = role === 'user'
            ? 'bg-gradient-to-br from-purple-600 to-indigo-600 rounded-tr-none'
            : 'bg-gray-700/80 rounded-tl-none';
        
        const layoutClasses = role === 'user' ? 'flex-row-reverse' : 'flex-row';

        return (
            <div className={`flex items-start gap-3 w-full ${layoutClasses}`}>
                {avatar}
                <div className={`px-4 py-3 rounded-xl max-w-md shadow-md text-gray-100 ${bubbleClasses} ${isCurrent ? 'opacity-70' : ''}`}>
                    {text}
                </div>
            </div>
        );
    }

    return (
        <div className="max-w-4xl mx-auto animate-fade-in">
            <Card
                title="Live Conversation"
                description="Talk with Gemini in real-time. Start the conversation and speak into your microphone."
            >
                <div className="flex flex-col items-center justify-center space-y-6">
                    <button
                        onClick={isConversationActive ? stopConversation : startConversation}
                        className={`relative w-24 h-24 rounded-full flex items-center justify-center text-white transition-all duration-300 transform hover:scale-105
                            ${isConversationActive ? 'bg-red-500 shadow-lg shadow-red-500/30' : 'bg-gradient-to-br from-purple-600 to-indigo-600 shadow-lg shadow-purple-500/30'}`}
                        aria-label={isConversationActive ? 'Stop conversation' : 'Start conversation'}
                    >
                        {isConversationActive && <span className="absolute h-full w-full rounded-full bg-red-500/80 animate-ping opacity-75"></span>}
                        <div className="w-8 h-8"><MicrophoneIcon isLive isRecording={isConversationActive}/></div>
                    </button>
                     <p className="text-gray-400 font-medium">
                        {connectionState === 'idle' && 'Tap to start'}
                        {connectionState === 'connecting' && 'Connecting...'}
                        {connectionState === 'connected' && 'Listening... Tap to stop.'}
                        {connectionState === 'closed' && 'Conversation ended. Tap to restart.'}
                        {connectionState === 'error' && 'Connection error. Tap to retry.'}
                    </p>
                </div>
                
                <div className="bg-gray-900/50 rounded-lg p-4 mt-6 min-h-[300px] max-h-[50vh] overflow-y-auto space-y-4">
                    {transcriptions.map((t, i) => (
                        <React.Fragment key={i}>
                            {t.user && renderTranscription(t.user, 'user', false)}
                            {t.model && renderTranscription(t.model, 'model', false)}
                        </React.Fragment>
                    ))}
                    {currentTranscription.user && renderTranscription(currentTranscription.user, 'user', true)}
                    {currentTranscription.model && renderTranscription(currentTranscription.model, 'model', true)}

                    {connectionState === 'idle' && transcriptions.length === 0 && (
                        <p className="text-gray-500 text-center pt-24">Your conversation will appear here.</p>
                    )}
                    <div ref={transcriptEndRef} />
                </div>
            </Card>
        </div>
    );
};

export default LiveConversation;