
import React, { useState, useEffect, useCallback } from 'react';
import { generateCharacterSheet, generateImage, generateStoryboards, generateVideo, pollVideoOperation, dataURLtoFile, blobToDataURL, generateScenePolish } from '../services/geminiService';
import { LoadingState } from '../types';
import LoadingSpinner from './common/LoadingSpinner';
import ApiKeyDialog from './common/ApiKeyDialog';
import Card from './ui/Card';
import ResetButton from './common/ResetButton';
import { useNotification } from '../hooks/useNotification';
import Button from './ui/Button';

type ProductionStep = 1 | 2 | 3 | 4;

const styles = ["Shonen", "Shojo", "Ghibli-esque", "Cyberpunk", "Dark Fantasy", "Mecha"];
const resolutions = [
    { name: '720p', value: '720p' as const },
    { name: '1080p', value: '1080p' as const },
    { name: '4K', value: '1080p' as const, note: 'Upscaled' },
    { name: '8K', value: '1080p' as const, note: 'Upscaled' },
];
const videoModels = [
    { id: 'veo-3.1-fast-generate-preview', name: 'Veo Fast' },
    { id: 'veo-3.1-generate-preview', name: 'Veo High Quality' },
];
const loadingMessages = ["Contacting the animation guild...", "Inking the keyframes...", "Coloring the cells...", "Rendering the final cut...", "The premiere is about to begin!"];

const StepIndicator: React.FC<{ currentStep: ProductionStep, step: ProductionStep, title: string, isComplete: boolean }> = ({ currentStep, step, title, isComplete }) => {
    const isActive = currentStep === step;
    const isFuture = step > currentStep;
    return (
        <div className="flex items-center">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-lg transition-all duration-300 ${isComplete ? 'bg-green-500 text-white' : isActive ? 'bg-purple-600 text-white' : 'bg-gray-700 text-gray-400'}`}>
                {isComplete ? '✓' : step}
            </div>
            <div className={`ml-3 transition-all duration-300 ${isActive ? 'text-purple-300 font-semibold' : isFuture ? 'text-gray-500' : 'text-gray-300'}`}>{title}</div>
        </div>
    )
};

const AnimeProductionStudio: React.FC = () => {
    // Overall State
    const [currentStep, setCurrentStep] = useState<ProductionStep>(1);
    const [apiKeySelected, setApiKeySelected] = useState(false);
    const addNotification = useNotification();
    
    // Step 1: Character Design State
    const [characterConcept, setCharacterConcept] = useState('');
    const [characterStyle, setCharacterStyle] = useState(styles[0]);
    const [characterSheet, setCharacterSheet] = useState<any>(null);
    const [characterImage, setCharacterImage] = useState<string | null>(null);
    const [step1Loading, setStep1Loading] = useState(false);

    // Step 2: Storyboarding State
    const [sceneDescription, setSceneDescription] = useState('');
    const [storyboards, setStoryboards] = useState<{ image: string; description: string }[]>([]);
    const [selectedStoryboard, setSelectedStoryboard] = useState<number | null>(null);
    const [step2Loading, setStep2Loading] = useState(false);
    
    // Step 3: Animation State
    const [animationResolution, setAnimationResolution] = useState(resolutions[1]);
    const [selectedVideoModel, setSelectedVideoModel] = useState(videoModels[0].id);
    const [animatedVideo, setAnimatedVideo] = useState<string | null>(null);
    const [step3Loading, setStep3Loading] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState(loadingMessages[0]);
    
    // Step 4: Polish State
    const [scenePolish, setScenePolish] = useState<{soundDesign: string; dialogue: string} | null>(null);
    const [step4Loading, setStep4Loading] = useState(false);

    const checkApiKey = useCallback(async () => {
        // @ts-ignore
        if (window.aistudio && await window.aistudio.hasSelectedApiKey()) {
            setApiKeySelected(true);
        } else {
            setApiKeySelected(false);
        }
    }, []);

    useEffect(() => {
        checkApiKey();
    }, [checkApiKey]);

    useEffect(() => {
        let interval: number;
        if (step3Loading) {
            interval = window.setInterval(() => {
                setLoadingMessage(prev => loadingMessages[(loadingMessages.indexOf(prev) + 1) % loadingMessages.length]);
            }, 3000);
        }
        return () => window.clearInterval(interval);
    }, [step3Loading]);

    const handleSelectKey = async () => {
        // @ts-ignore
        if (window.aistudio) {
            // @ts-ignore
            await window.aistudio.openSelectKey();
            setApiKeySelected(true);
        }
    };
    
    const handleReset = () => {
        setCurrentStep(1);
        setCharacterConcept('');
        setCharacterStyle(styles[0]);
        setCharacterSheet(null);
        setCharacterImage(null);
        setStep1Loading(false);
        setSceneDescription('');
        setStoryboards([]);
        setSelectedStoryboard(null);
        setStep2Loading(false);
        setAnimationResolution(resolutions[1]);
        setSelectedVideoModel(videoModels[0].id);
        setAnimatedVideo(null);
        setStep3Loading(false);
        setScenePolish(null);
        setStep4Loading(false);
        addNotification('Anime Studio has been reset.', 'info');
    };

    const handleGenerateCharacter = async () => {
        if (!characterConcept) return;
        setStep1Loading(true);
        setCharacterImage(null);
        setCharacterSheet(null);
        try {
            const sheetData = await generateCharacterSheet(characterConcept, characterStyle);
            setCharacterSheet(sheetData.sheet);
            const imageUrl = await generateImage(sheetData.fullPrompt, "9:16", 'imagen-4.0-generate-001');
            setCharacterImage(imageUrl);
            setCurrentStep(2);
            addNotification('Character design complete!', 'success');
        } catch (e) {
            console.error(e);
            addNotification('Failed to generate character.', 'error');
        } finally {
            setStep1Loading(false);
        }
    };
    
    const handleGenerateStoryboards = async () => {
        if (!sceneDescription || !characterImage) return;
        setStep2Loading(true);
        setStoryboards([]);
        setSelectedStoryboard(null);
        try {
            const imageFile = dataURLtoFile(characterImage, 'character.jpg');
            if (!imageFile) throw new Error("Could not prepare character image.");
            const { panels } = await generateStoryboards(sceneDescription, imageFile, characterSheet);
            setStoryboards(panels);
            setCurrentStep(3);
            addNotification('Storyboards created!', 'success');
        } catch (e) {
            console.error(e);
            addNotification('Failed to create storyboards.', 'error');
        } finally {
            setStep2Loading(false);
        }
    }
    
    const handleAnimate = async () => {
        if (selectedStoryboard === null || !storyboards[selectedStoryboard]) return;
        if (!apiKeySelected) {
            addNotification("Please select an API key to generate video.", "info");
            handleSelectKey();
            return;
        }
        setStep3Loading(true);
        setAnimatedVideo(null);
        try {
            const storyboardFile = dataURLtoFile(storyboards[selectedStoryboard].image, 'storyboard.jpg');
            if (!storyboardFile) throw new Error("Could not prepare storyboard image.");

            const prompt = `An anime scene of ${characterSheet.name}. ${storyboards[selectedStoryboard].description}. ${sceneDescription}`;
            let op = await generateVideo(prompt, storyboardFile, '16:9', selectedVideoModel, animationResolution.value);
            while(!op.done) {
                await new Promise(r => setTimeout(r, 10000));
                op = await pollVideoOperation(op);
            }

            if (op.response?.generatedVideos?.[0]?.video?.uri) {
                const downloadLink = op.response.generatedVideos[0].video.uri;
                const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
                const blob = await response.blob();
                const dataUrl = await blobToDataURL(blob);
                setAnimatedVideo(dataUrl);
                setCurrentStep(4);
                addNotification('Animation complete!', 'success');
            } else {
                 throw new Error("Animation finished but no video was returned.");
            }
        } catch (e) {
            console.error(e);
            let msg = 'Failed to animate scene.';
            // @ts-ignore
            if (e.message?.includes("not found")) { msg = "Invalid API Key. Please select another."; setApiKeySelected(false); }
            addNotification(msg, 'error');
        } finally {
            setStep3Loading(false);
        }
    }
    
    const handlePolish = async () => {
        if (!sceneDescription || !characterSheet) return;
        setStep4Loading(true);
        setScenePolish(null);
        try {
            const result = await generateScenePolish(sceneDescription, characterSheet);
            setScenePolish(result);
            addNotification('Scene polish added!', 'success');
        } catch(e) {
            console.error(e);
            addNotification('Failed to add scene polish.', 'error');
        } finally {
            setStep4Loading(false);
        }
    }

    return (
        <div className="max-w-6xl mx-auto animate-fade-in space-y-6">
            <Card title="Anime Production Studio" description="Follow the steps below to create your own animated anime scene from scratch." actions={<ResetButton onReset={handleReset} />}>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 p-4 rounded-lg bg-gray-900/50 border-b border-gray-700">
                    <StepIndicator currentStep={currentStep} step={1} title="Character Design" isComplete={currentStep > 1} />
                    <StepIndicator currentStep={currentStep} step={2} title="Storyboarding" isComplete={currentStep > 2} />
                    <StepIndicator currentStep={currentStep} step={3} title="Animation" isComplete={currentStep > 3} />
                    <StepIndicator currentStep={currentStep} step={4} title="Scene Polish" isComplete={!!scenePolish} />
                </div>
            </Card>

            {/* --- STEP 1: CHARACTER DESIGN --- */}
            <Card className={currentStep === 1 ? 'border-purple-500' : ''}>
                <h3 className="text-xl font-semibold text-purple-300 mb-4">Step 1: Character Design</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                        <textarea value={characterConcept} onChange={e => setCharacterConcept(e.target.value)} placeholder="Describe your character's concept..." className="w-full bg-gray-900/50 border border-gray-600 rounded-md p-2 focus:ring-2 focus:ring-purple-500 min-h-[120px]"/>
                        <div>
                            <label className="block text-sm font-medium text-gray-300 mb-2">Art Style</label>
                            <div className="flex flex-wrap gap-2">
                                {styles.map(s => <Button key={s} type="button" variant={characterStyle === s ? 'primary' : 'secondary'} onClick={() => setCharacterStyle(s)}>{s}</Button>)}
                            </div>
                        </div>
                        <Button onClick={handleGenerateCharacter} disabled={step1Loading || !characterConcept} className="w-full">{step1Loading ? 'Designing...' : 'Generate Character'}</Button>
                    </div>
                    <div>
                        {step1Loading && <div className="h-full flex items-center justify-center"><LoadingSpinner /></div>}
                        {characterImage && <img src={characterImage} alt="Character Design" className="rounded-lg shadow-lg w-full" />}
                        {characterSheet && !characterImage && !step1Loading && <p className="text-red-400">Image failed to load, but sheet was generated. Try again.</p>}
                    </div>
                </div>
                {characterSheet && (
                     <div className="mt-4 bg-gray-900/50 p-4 rounded-lg">
                        <h4 className="font-bold text-lg mb-2 text-purple-400">{characterSheet.name}</h4>
                        <p><strong className="text-gray-400">Backstory:</strong> {characterSheet.backstory}</p>
                        <p><strong className="text-gray-400">Personality:</strong> {characterSheet.personality}</p>
                    </div>
                )}
            </Card>

            {/* --- STEP 2: STORYBOARDING --- */}
            <Card className={currentStep === 2 ? 'border-purple-500' : ''}>
                 <h3 className="text-xl font-semibold text-purple-300 mb-4">Step 2: Storyboarding</h3>
                 <div className="space-y-4">
                     <textarea value={sceneDescription} onChange={e => setSceneDescription(e.target.value)} placeholder="Describe the scene for your character..." className="w-full bg-gray-900/50 border border-gray-600 rounded-md p-2 focus:ring-2 focus:ring-purple-500 min-h-[120px]" disabled={currentStep < 2}/>
                     <Button onClick={handleGenerateStoryboards} disabled={step2Loading || !sceneDescription || currentStep < 2} className="w-full">{step2Loading ? 'Drawing...' : 'Generate Storyboards'}</Button>
                 </div>
                 {step2Loading && <div className="mt-4"><LoadingSpinner /></div>}
                 {storyboards.length > 0 && (
                     <div className="mt-4">
                         <p className="text-center text-gray-400 mb-2">Select a panel to animate:</p>
                         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                             {storyboards.map((panel, i) => (
                                 <div key={i} onClick={() => setSelectedStoryboard(i)} className={`p-2 rounded-lg cursor-pointer transition-all ${selectedStoryboard === i ? 'bg-purple-600/50 ring-2 ring-purple-400' : 'bg-gray-800/50'}`}>
                                     <img src={panel.image} alt={`Storyboard panel ${i+1}`} className="rounded-md w-full" />
                                     <p className="text-xs text-gray-300 mt-2 text-center bg-gray-900/50 p-1 rounded">{panel.description}</p>
                                 </div>
                             ))}
                         </div>
                     </div>
                 )}
            </Card>
            
            {/* --- STEP 3: ANIMATION --- */}
            <Card className={currentStep === 3 ? 'border-purple-500' : ''}>
                 <h3 className="text-xl font-semibold text-purple-300 mb-4">Step 3: Animation</h3>
                 {!apiKeySelected && currentStep >= 3 && <ApiKeyDialog onSelectKey={handleSelectKey} />}
                 {apiKeySelected && (
                     <div className="space-y-4">
                         <div>
                            <label className="block text-sm font-medium text-gray-300 mb-2">Animation Model</label>
                            <div className="flex flex-wrap gap-2">{videoModels.map(m => <Button key={m.id} type="button" variant={selectedVideoModel === m.id ? 'primary' : 'secondary'} onClick={() => setSelectedVideoModel(m.id)}>{m.name}</Button>)}</div>
                         </div>
                         <div>
                            <label className="block text-sm font-medium text-gray-300 mb-2">Resolution</label>
                            <div className="flex flex-wrap gap-2">{resolutions.map(r => <Button key={r.name} type="button" variant={animationResolution.name === r.name ? 'primary' : 'secondary'} onClick={() => setAnimationResolution(r)}>{r.name}{r.note && <span className="text-xs ml-1 opacity-70">({r.note})</span>}</Button>)}</div>
                         </div>
                         <Button onClick={handleAnimate} disabled={step3Loading || selectedStoryboard === null || currentStep < 3} className="w-full">{step3Loading ? 'Animating...' : 'Animate Selected Scene'}</Button>
                     </div>
                 )}
                 {step3Loading && (
                    <div className="text-center p-4 space-y-4">
                        <LoadingSpinner />
                        <p className="text-purple-300 animate-pulse">{loadingMessage}</p>
                    </div>
                )}
                {animatedVideo && (
                    <div className="mt-4">
                        <video src={animatedVideo} controls autoPlay loop className="rounded-lg shadow-lg w-full" />
                        <a href={animatedVideo} download="anime-scene.mp4" className="block text-center mt-2 text-purple-400 hover:underline">Download Animation</a>
                    </div>
                )}
            </Card>

            {/* --- STEP 4: SCENE POLISH --- */}
            <Card className={currentStep === 4 ? 'border-purple-500' : ''}>
                 <h3 className="text-xl font-semibold text-purple-300 mb-4">Step 4: Scene Polish</h3>
                 <Button onClick={handlePolish} disabled={step4Loading || !animatedVideo || currentStep < 4} className="w-full">{step4Loading ? 'Polishing...' : 'Add Final Polish (Sound & Dialogue)'}</Button>
                 {step4Loading && <div className="mt-4"><LoadingSpinner /></div>}
                 {scenePolish && (
                     <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                         <div className="bg-gray-900/50 p-4 rounded-lg">
                            <h4 className="font-bold text-lg mb-2 text-purple-400">Sound Design</h4>
                            <p className="text-gray-300 italic">"{scenePolish.soundDesign}"</p>
                         </div>
                         <div className="bg-gray-900/50 p-4 rounded-lg">
                            <h4 className="font-bold text-lg mb-2 text-purple-400">Dialogue</h4>
                            <p className="text-gray-300"><strong className="text-gray-400">{characterSheet.name}:</strong> "{scenePolish.dialogue}"</p>
                         </div>
                     </div>
                 )}
            </Card>

        </div>
    );
};

export default AnimeProductionStudio;