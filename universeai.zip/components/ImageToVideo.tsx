import React, { useState, useEffect, useCallback, useRef } from 'react';
import { generateVideo, pollVideoOperation, blobToDataURL, fileToDataURL } from '../services/geminiService';
import { LoadingState } from '../types';
import ApiKeyDialog from './common/ApiKeyDialog';
import Card from './ui/Card';
import ResetButton from './common/ResetButton';
import { useNotification } from '../hooks/useNotification';
import Button from './ui/Button';

const loadingMessages = [
    "Animating your still image...",
    "Breathing life into pixels...",
    "Rendering your image into a video masterpiece...",
    "Adding a touch of cinematic motion...",
    "Your video is almost ready!",
];

const videoModels = [
    { id: 'veo-3.1-fast-generate-preview', name: 'Veo 3.1 Fast' },
    { id: 'veo-3.1-generate-preview', name: 'Veo 3.1 High Quality' },
];

const ImageToVideo: React.FC = () => {
    const [prompt, setPrompt] = useState('');
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [originalImageUrl, setOriginalImageUrl] = useState<string | null>(null);
    const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);
    const [selectedModel, setSelectedModel] = useState(videoModels[0].id);
    const [loading, setLoading] = useState<LoadingState>('idle');
    const [error, setError] = useState<string | null>(null);
    const [apiKeySelected, setApiKeySelected] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState(loadingMessages[0]);
    const addNotification = useNotification();
    
    const imageRef = useRef<HTMLImageElement>(null);

    const checkApiKey = useCallback(async () => {
        // @ts-ignore
        if (window.aistudio && await window.aistudio.hasSelectedApiKey()) {
            setApiKeySelected(true);
        } else {
            setApiKeySelected(false);
        }
    }, []);

    useEffect(() => {
        checkApiKey();
        const interval = setInterval(checkApiKey, 2000);
        return () => clearInterval(interval);
    }, [checkApiKey]);
    
    useEffect(() => {
        let interval: number;
        if (loading === 'loading') {
            interval = window.setInterval(() => {
                setLoadingMessage(prev => {
                    const currentIndex = loadingMessages.indexOf(prev);
                    return loadingMessages[(currentIndex + 1) % loadingMessages.length];
                });
            }, 3000);
        }
        return () => window.clearInterval(interval);
    }, [loading]);
    
    const handleSelectKey = async () => {
        // @ts-ignore
        if (window.aistudio) {
            // @ts-ignore
            await window.aistudio.openSelectKey();
            setApiKeySelected(true); 
        }
    };

    const handleReset = () => {
        setPrompt('');
        setImageFile(null);
        setOriginalImageUrl(null);
        setGeneratedVideoUrl(null);
        setSelectedModel(videoModels[0].id);
        setLoading('idle');
        setError(null);
        addNotification('Image to Video tool has been reset.', 'info');
    };

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setImageFile(file);
            const url = await fileToDataURL(file);
            setOriginalImageUrl(url);
            setGeneratedVideoUrl(null);
            setError(null);
            addNotification('Image uploaded successfully.', 'success');
        }
    };
    
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!imageFile) {
            setError("An image is required to generate a video.");
            return;
        }

        if (!imageRef.current) {
            setError("Image not loaded correctly. Please try re-uploading.");
            return;
        }

        setLoading('loading');
        setGeneratedVideoUrl(null);
        setError(null);
        setLoadingMessage(loadingMessages[0]);
        
        try {
            const aspectRatio = imageRef.current.naturalWidth > imageRef.current.naturalHeight ? '16:9' : '9:16';
            
            let operation = await generateVideo(prompt, imageFile, aspectRatio, selectedModel);
            
            while (!operation.done) {
                await new Promise(resolve => setTimeout(resolve, 10000));
                operation = await pollVideoOperation(operation);
            }

            if (operation.response?.generatedVideos?.[0]?.video?.uri) {
                const downloadLink = operation.response.generatedVideos[0].video.uri;
                const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
                const blob = await response.blob();
                const dataUrl = await blobToDataURL(blob);
                setGeneratedVideoUrl(dataUrl);
                setLoading('success');
                addNotification('Video generated from image!', 'success');
            } else {
                throw new Error("Video generation completed, but no video URI was found.");
            }

        } catch (err: any) {
            console.error(err);
            let errorMessage = 'Failed to generate video. Please try again.';
            if (err?.message?.includes("Requested entity was not found")) {
                errorMessage = "API Key not found or invalid. Please select a valid API key.";
                setApiKeySelected(false);
            }
            setError(errorMessage);
            setLoading('error');
        }
    };

    if (!apiKeySelected) {
        return <ApiKeyDialog onSelectKey={handleSelectKey} />;
    }

    return (
        <div className="max-w-4xl mx-auto animate-fade-in">
            <Card
                title="Image to Video"
                description="Bring your static images to life. Upload an image, provide an optional prompt, and generate a dynamic video."
                actions={<ResetButton onReset={handleReset} />}
            >
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="image-upload" className="block text-sm font-medium text-gray-300 mb-1">1. Upload Your Image</label>
                        <input
                            id="image-upload"
                            type="file"
                            accept="image/*"
                            onChange={handleFileChange}
                            className="w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-gray-600 file:text-white hover:file:bg-gray-500"
                        />
                    </div>
                    <div>
                        <label htmlFor="prompt" className="block text-sm font-medium text-gray-300 mb-1">2. Describe the Motion (Optional)</label>
                        <textarea
                            id="prompt"
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="e.g., The camera slowly zooms in on the character's face."
                            className="w-full bg-gray-900/50 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500 min-h-[80px]"
                            disabled={!imageFile}
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">3. Select Model</label>
                        <div className="flex flex-wrap gap-2">
                            {videoModels.map(model => (
                                <Button
                                    key={model.id}
                                    type="button"
                                    variant={selectedModel === model.id ? 'primary' : 'secondary'}
                                    onClick={() => setSelectedModel(model.id)}
                                >
                                    {model.name}
                                </Button>
                            ))}
                        </div>
                    </div>
                    <Button
                        type="submit"
                        className="w-full"
                        disabled={loading === 'loading' || !imageFile}
                    >
                        {loading === 'loading' ? 'Generating Video...' : 'Generate Video'}
                    </Button>
                </form>

                {loading === 'loading' && (
                    <div className="text-center p-4 space-y-4">
                        <div className="w-full bg-gray-700 rounded-full h-2.5 overflow-hidden">
                            <div className="bg-purple-600 h-2.5 rounded-full animate-pulse" style={{width: '100%', animation: 'indeterminate-progress 2s infinite ease-in-out'}}></div>
                        </div>
                        <p className="text-purple-300 animate-pulse">{loadingMessage}</p>
                        <p className="text-sm text-gray-400">Video generation can take a few minutes. Please be patient.</p>
                    </div>
                )}
                {error && <p className="text-red-400 text-center">{error}</p>}
                
                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                    {originalImageUrl && (
                        <div>
                            <h3 className="text-lg font-semibold mb-2 text-center">Original Image</h3>
                            <img ref={imageRef} src={originalImageUrl} alt="Uploaded for video generation" className="rounded-lg shadow-lg w-full" />
                        </div>
                    )}
                    {generatedVideoUrl && (
                        <div>
                            <h3 className="text-lg font-semibold mb-2 text-center">Generated Video</h3>
                            <video src={generatedVideoUrl} controls autoPlay loop className="rounded-lg shadow-lg w-full" />
                            <a href={generatedVideoUrl} download="image-to-video.mp4" className="block text-center mt-4 text-purple-400 hover:underline">Download Video</a>
                        </div>
                    )}
                </div>
            </Card>
            <style>{`
                @keyframes indeterminate-progress {
                    0% { transform: translateX(-100%); }
                    100% { transform: translateX(100%); }
                }
            `}</style>
        </div>
    );
};

export default ImageToVideo;