
import React, { useState, useEffect } from 'react';
import { generateEbook } from '../services/geminiService';
import { LoadingState } from '../types';
import LoadingSpinner from './common/LoadingSpinner';
import Card from './ui/Card';
import ResetButton from './common/ResetButton';
import { useNotification } from '../hooks/useNotification';

interface Ebook {
    title: string;
    chapters: {
        title: string;
        content: string;
    }[];
}

const EbookGenerator: React.FC = () => {
    const [prompt, setPrompt] = useState(() => localStorage.getItem('ebook_prompt') || '');
    const [ebook, setEbook] = useState<Ebook | null>(() => {
        const savedEbook = localStorage.getItem('ebook_result');
        return savedEbook ? JSON.parse(savedEbook) : null;
    });
    const [loading, setLoading] = useState<LoadingState>('idle');
    const [error, setError] = useState<string | null>(null);
    const addNotification = useNotification();

    useEffect(() => {
        localStorage.setItem('ebook_prompt', prompt);
    }, [prompt]);

    useEffect(() => {
        if (ebook) {
            localStorage.setItem('ebook_result', JSON.stringify(ebook));
        } else {
            localStorage.removeItem('ebook_result');
        }
    }, [ebook]);

    const handleReset = () => {
        setPrompt('');
        setEbook(null);
        setLoading('idle');
        setError(null);
        localStorage.removeItem('ebook_prompt');
        localStorage.removeItem('ebook_result');
        addNotification('Ebook Generator reset.', 'info');
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!prompt.trim()) return;

        setLoading('loading');
        setEbook(null);
        setError(null);
        try {
            const response = await generateEbook(prompt);
            setEbook(response);
            setLoading('success');
        } catch (err: any) {
            console.error(err);
            setError(err.message || 'Failed to generate the ebook. Please try again.');
            setLoading('error');
        }
    };

    return (
        <div className="max-w-4xl mx-auto animate-fade-in">
            <Card
                title="AI Ebook Generator"
                description="Provide a topic and let Gemini 2.5 Pro write a complete, structured ebook for you."
                actions={<ResetButton onReset={handleReset} />}
            >
                <form onSubmit={handleSubmit} className="space-y-4">
                    <textarea
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder="Enter the topic for your ebook, e.g., 'A beginner's guide to deep space astronomy' or 'The history of ancient Rome'"
                        className="w-full bg-gray-900/50 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500 min-h-[120px]"
                        required
                    />
                    <button
                        type="submit"
                        className="w-full bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-700 transition-colors disabled:bg-gray-500"
                        disabled={loading === 'loading'}
                    >
                        {loading === 'loading' ? 'Writing...' : 'Generate Ebook'}
                    </button>
                </form>

                {loading === 'loading' && <div className="text-center p-4 space-y-2"><LoadingSpinner /><p>Generating your ebook, this may take a moment...</p></div>}
                {error && <p className="text-red-400 text-center">{error}</p>}

                {ebook && (
                    <div className="mt-6 p-4 bg-gray-900/50 rounded-lg">
                        <h2 className="text-3xl font-bold mb-6 text-center text-purple-300 border-b border-gray-700 pb-4">{ebook.title}</h2>
                        <div className="space-y-8">
                            {ebook.chapters.map((chapter, index) => (
                                <div key={index}>
                                    <h3 className="text-2xl font-semibold mb-3 text-teal-300">{`Chapter ${index + 1}: ${chapter.title}`}</h3>
                                    <p className="whitespace-pre-wrap text-gray-300 leading-relaxed">{chapter.content}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </Card>
        </div>
    );
};

export default EbookGenerator;