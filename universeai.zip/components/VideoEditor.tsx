
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { generateVideo, pollVideoOperation, blobToDataURL } from '../services/geminiService';
import { LoadingState } from '../types';
import ApiKeyDialog from './common/ApiKeyDialog';
import Card from './ui/Card';
import ResetButton from './common/ResetButton';
import { useNotification } from '../hooks/useNotification';
import Button from './ui/Button';

const loadingMessages = [
    "Analyzing the final scene...",
    "Setting up for the sequel...",
    "Generating the next chapter of your story...",
    "Adding a new twist to the plot...",
    "Rendering the extended cut!",
];

const videoModels = [
    { id: 'veo-3.1-fast-generate-preview', name: 'Veo 3.1 Fast' },
    { id: 'veo-3.1-generate-preview', name: 'Veo 3.1 High Quality' },
];

const VideoEditor: React.FC = () => {
    const [prompt, setPrompt] = useState('');
    const [videoFile, setVideoFile] = useState<File | null>(null);
    const [originalVideoUrl, setOriginalVideoUrl] = useState<string | null>(null);
    const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);
    const [selectedModel, setSelectedModel] = useState(videoModels[0].id);
    const [loading, setLoading] = useState<LoadingState>('idle');
    const [error, setError] = useState<string | null>(null);
    const [apiKeySelected, setApiKeySelected] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState(loadingMessages[0]);
    const addNotification = useNotification();
    
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);

    const checkApiKey = useCallback(async () => {
        // @ts-ignore
        if (window.aistudio && await window.aistudio.hasSelectedApiKey()) {
            setApiKeySelected(true);
        } else {
            setApiKeySelected(false);
        }
    }, []);

    useEffect(() => {
        checkApiKey();
        const interval = setInterval(checkApiKey, 2000);
        return () => clearInterval(interval);
    }, [checkApiKey]);
    
    useEffect(() => {
        let interval: number;
        if (loading === 'loading') {
            interval = window.setInterval(() => {
                setLoadingMessage(prev => {
                    const currentIndex = loadingMessages.indexOf(prev);
                    return loadingMessages[(currentIndex + 1) % loadingMessages.length];
                });
            }, 3000);
        }
        return () => window.clearInterval(interval);
    }, [loading]);
    
    const handleSelectKey = async () => {
        // @ts-ignore
        if (window.aistudio) {
            // @ts-ignore
            await window.aistudio.openSelectKey();
            setApiKeySelected(true); 
        }
    };

    const handleReset = () => {
        setPrompt('');
        setVideoFile(null);
        setOriginalVideoUrl(null);
        setGeneratedVideoUrl(null);
        setSelectedModel(videoModels[0].id);
        setLoading('idle');
        setError(null);
        if (videoRef.current) videoRef.current.src = '';
        addNotification('Video Editor reset.', 'info');
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setVideoFile(file);
            const url = URL.createObjectURL(file);
            setOriginalVideoUrl(url);
            setGeneratedVideoUrl(null);
            setError(null);
            addNotification('Video uploaded successfully.', 'success');
        }
    };
    
    const extractLastFrame = (): Promise<File> => {
        return new Promise((resolve, reject) => {
            if (!videoRef.current || !canvasRef.current || !videoRef.current.duration) {
                return reject(new Error("Video element is not ready."));
            }

            const video = videoRef.current;
            const canvas = canvasRef.current;
            const ctx = canvas.getContext('2d');

            if (!ctx) {
                return reject(new Error("Canvas context could not be retrieved."));
            }
            
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;

            const onSeeked = () => {
                video.removeEventListener('seeked', onSeeked);
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                canvas.toBlob(blob => {
                    if (blob) {
                        resolve(new File([blob], "last_frame.jpeg", { type: "image/jpeg" }));
                    } else {
                        reject(new Error("Failed to create blob from canvas."));
                    }
                }, 'image/jpeg', 0.9);
            };
            
            video.addEventListener('seeked', onSeeked, { once: true });
            video.currentTime = video.duration;
        });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!prompt.trim() || !videoFile) {
            setError("Both a video and a prompt are required.");
            return;
        }

        setLoading('loading');
        setGeneratedVideoUrl(null);
        setError(null);
        setLoadingMessage(loadingMessages[0]);
        
        try {
            const lastFrameFile = await extractLastFrame();
            const videoAspectRatio = videoRef.current!.videoWidth > videoRef.current!.videoHeight ? '16:9' : '9:16';
            
            let operation = await generateVideo(prompt, lastFrameFile, videoAspectRatio, selectedModel);
            
            while (!operation.done) {
                await new Promise(resolve => setTimeout(resolve, 10000));
                operation = await pollVideoOperation(operation);
            }

            if (operation.response?.generatedVideos?.[0]?.video?.uri) {
                const downloadLink = operation.response.generatedVideos[0].video.uri;
                const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
                const blob = await response.blob();
                const dataUrl = await blobToDataURL(blob);
                setGeneratedVideoUrl(dataUrl);
                setLoading('success');
                addNotification('Video extension generated!', 'success');
            } else {
                throw new Error("Video generation completed, but no video URI was found.");
            }

        } catch (err: any) {
            console.error(err);
            let errorMessage = 'Failed to generate video extension. Please try again.';
            if (err?.message?.includes("Requested entity was not found")) {
                errorMessage = "API Key not found or invalid. Please select a valid API key.";
                setApiKeySelected(false);
            }
            setError(errorMessage);
            setLoading('error');
        }
    };

    if (!apiKeySelected) {
        return <ApiKeyDialog onSelectKey={handleSelectKey} />;
    }

    return (
        <div className="max-w-4xl mx-auto animate-fade-in">
            <Card
                title="Generative Video Editor"
                description="Extend your video by uploading it and describing what should happen next. The AI will generate a new clip starting from your video's last frame."
                actions={<ResetButton onReset={handleReset} />}
            >
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="video-upload" className="block text-sm font-medium text-gray-300 mb-1">1. Upload Your Video</label>
                        <input
                            id="video-upload"
                            type="file"
                            accept="video/*"
                            onChange={handleFileChange}
                            className="w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-gray-600 file:text-white hover:file:bg-gray-500"
                        />
                         <canvas ref={canvasRef} className="hidden"></canvas>
                    </div>
                    <div>
                        <label htmlFor="prompt" className="block text-sm font-medium text-gray-300 mb-1">2. Describe What Happens Next</label>
                        <textarea
                            id="prompt"
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="e.g., ...and then a spaceship lands in the background."
                            className="w-full bg-gray-900/50 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500 min-h-[80px]"
                            disabled={!videoFile}
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">3. Select Model</label>
                        <div className="flex flex-wrap gap-2">
                            {videoModels.map(model => (
                                <Button
                                    key={model.id}
                                    type="button"
                                    variant={selectedModel === model.id ? 'primary' : 'secondary'}
                                    onClick={() => setSelectedModel(model.id)}
                                >
                                    {model.name}
                                </Button>
                            ))}
                        </div>
                    </div>
                    <Button
                        type="submit"
                        className="w-full"
                        disabled={loading === 'loading' || !videoFile || !prompt.trim()}
                    >
                        {loading === 'loading' ? 'Generating Extension...' : 'Generate Extension'}
                    </Button>
                </form>

                {loading === 'loading' && (
                    <div className="text-center p-4 space-y-4">
                        <div className="w-full bg-gray-700 rounded-full h-2.5 overflow-hidden">
                            <div className="bg-purple-600 h-2.5 rounded-full animate-pulse" style={{width: '100%', animation: 'indeterminate-progress 2s infinite ease-in-out'}}></div>
                        </div>
                        <p className="text-purple-300 animate-pulse">{loadingMessage}</p>
                        <p className="text-sm text-gray-400">Video generation can take a few minutes. Please be patient.</p>
                    </div>
                )}
                {error && <p className="text-red-400 text-center">{error}</p>}
                
                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                    {originalVideoUrl && (
                        <div>
                            <h3 className="text-lg font-semibold mb-2 text-center">Original Video</h3>
                            <video ref={videoRef} src={originalVideoUrl} controls className="rounded-lg shadow-lg w-full" />
                        </div>
                    )}
                    {generatedVideoUrl && (
                        <div>
                            <h3 className="text-lg font-semibold mb-2 text-center">Generated Extension</h3>
                            <video src={generatedVideoUrl} controls autoPlay loop className="rounded-lg shadow-lg w-full" />
                            <a href={generatedVideoUrl} download="extended-video.mp4" className="block text-center mt-4 text-purple-400 hover:underline">Download Extension</a>
                        </div>
                    )}
                </div>
            </Card>
            <style>{`
                @keyframes indeterminate-progress {
                    0% { transform: translateX(-100%); }
                    100% { transform: translateX(100%); }
                }
            `}</style>
        </div>
    );
};

export default VideoEditor;