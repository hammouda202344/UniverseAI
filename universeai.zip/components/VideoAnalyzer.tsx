
import React, { useState, useRef, useEffect } from 'react';
import { analyzeVideo } from '../services/geminiService';
import { LoadingState } from '../types';
import LoadingSpinner from './common/LoadingSpinner';
import Card from './ui/Card';
import ResetButton from './common/ResetButton';
import { useNotification } from '../hooks/useNotification';

const FRAME_COUNT = 8; // Number of frames to extract

const VideoAnalyzer: React.FC = () => {
    const [prompt, setPrompt] = useState(() => localStorage.getItem('videoAnalyzer_prompt') || 'Describe what is happening in this video. Identify the main subjects and their actions.');
    const [videoFile, setVideoFile] = useState<File | null>(null);
    const [videoUrl, setVideoUrl] = useState<string | null>(null);
    const [analysis, setAnalysis] = useState<string | null>(() => localStorage.getItem('videoAnalyzer_analysis') || null);
    const [loading, setLoading] = useState<LoadingState>('idle');
    const [error, setError] = useState<string | null>(null);
    const videoRef = useRef<HTMLVideoElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const addNotification = useNotification();

    useEffect(() => {
        localStorage.setItem('videoAnalyzer_prompt', prompt);
    }, [prompt]);

    useEffect(() => {
        if (analysis) {
            localStorage.setItem('videoAnalyzer_analysis', analysis);
        } else {
            localStorage.removeItem('videoAnalyzer_analysis');
        }
    }, [analysis]);


    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setVideoFile(file);
            setVideoUrl(URL.createObjectURL(file));
            setAnalysis(null);
            setError(null);
        }
    };

    const handleReset = () => {
        setPrompt('Describe what is happening in this video. Identify the main subjects and their actions.');
        setVideoFile(null);
        setVideoUrl(null);
        setAnalysis(null);
        setLoading('idle');
        setError(null);
        localStorage.removeItem('videoAnalyzer_prompt');
        localStorage.removeItem('videoAnalyzer_analysis');
        if (videoRef.current) videoRef.current.src = '';
        addNotification('Video Analyzer reset.', 'info');
    };
    
    const extractFrames = (): Promise<string[]> => {
        return new Promise((resolve, reject) => {
            if (!videoRef.current || !canvasRef.current || !videoRef.current.duration) {
                return reject("Video or canvas element not ready.");
            }
            
            const video = videoRef.current;
            const canvas = canvasRef.current;
            const ctx = canvas.getContext('2d');
            if (!ctx) return reject("Canvas context not available.");

            const frames: string[] = [];
            const interval = video.duration / FRAME_COUNT;
            let currentTime = 0;
            let framesExtracted = 0;

            video.onseeked = () => {
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                canvas.toBlob(blob => {
                    if (blob) {
                        const reader = new FileReader();
                        reader.onload = () => {
                            const base64 = (reader.result as string).split(',')[1];
                            frames.push(base64);
                            framesExtracted++;
                            
                            if (framesExtracted === FRAME_COUNT) {
                                video.onseeked = null; // Cleanup
                                resolve(frames);
                            } else {
                                currentTime += interval;
                                video.currentTime = Math.min(currentTime, video.duration);
                            }
                        };
                        reader.readAsDataURL(blob);
                    }
                }, 'image/jpeg', 0.8);
            };
            
            video.currentTime = 0;
        });
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!prompt.trim() || !videoFile) return;

        setLoading('loading');
        setAnalysis(null);
        setError(null);

        try {
            const frames = await extractFrames();
            if (frames.length === 0) throw new Error("Could not extract frames from video.");
            
            const result = await analyzeVideo(prompt, frames);
            setAnalysis(result);
            setLoading('success');
        } catch (err) {
            console.error(err);
            setError('Failed to analyze video. Please try again.');
            setLoading('error');
        }
    };
    
    const onVideoLoaded = () => {
        if (videoRef.current && canvasRef.current) {
             canvasRef.current.width = videoRef.current.videoWidth;
             canvasRef.current.height = videoRef.current.videoHeight;
        }
    };

    return (
        <div className="max-w-4xl mx-auto animate-fade-in">
            <Card
                title="Video Content Analysis"
                description="Upload a video and get a detailed AI-powered analysis of its contents."
                actions={<ResetButton onReset={handleReset} />}
            >
                <div className="space-y-4">
                    <div>
                        <label htmlFor="video-upload" className="block text-sm font-medium text-gray-300 mb-1">Upload Video</label>
                        <input
                            id="video-upload"
                            type="file"
                            accept="video/*"
                            onChange={handleFileChange}
                            className="w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-purple-600 file:text-white hover:file:bg-purple-700"
                        />
                    </div>
                     {videoUrl && <video ref={videoRef} src={videoUrl} onLoadedMetadata={onVideoLoaded} controls className="rounded-lg shadow-lg mx-auto max-w-full max-h-80" />}
                     <canvas ref={canvasRef} className="hidden"></canvas>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <textarea
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            placeholder="e.g., What is in this video? Provide details about the main subject."
                            className="w-full bg-gray-900/50 border border-gray-600 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-purple-500 min-h-[80px]"
                            required
                            disabled={!videoFile}
                        />
                        <button
                            type="submit"
                            className="w-full bg-purple-600 text-white font-bold py-2 px-4 rounded-md hover:bg-purple-700 transition-colors disabled:bg-gray-500"
                            disabled={loading === 'loading' || !prompt.trim() || !videoFile}
                        >
                            {loading === 'loading' ? 'Analyzing...' : 'Analyze Video'}
                        </button>
                    </form>
                </div>

                {loading === 'loading' && <div className="text-center p-4 space-y-2"><LoadingSpinner /><p>Extracting frames and analyzing...</p></div>}
                {error && <p className="text-red-400 text-center mt-4">{error}</p>}
                
                {analysis && (
                    <div className="mt-6 p-4 bg-gray-900/50 rounded-lg">
                        <h3 className="text-lg font-semibold mb-2 text-purple-300">Analysis Result:</h3>
                        <p className="whitespace-pre-wrap text-gray-200">{analysis}</p>
                    </div>
                )}
            </Card>
        </div>
    );
};

export default VideoAnalyzer;