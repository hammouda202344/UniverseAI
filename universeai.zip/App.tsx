
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import { Feature } from './types';
import ImageGenerator from './components/ImageGenerator';
import VideoGenerator from './components/VideoGenerator';
import LiveConversation from './components/LiveConversation';
import GroundingSearch from './components/GroundingSearch';
import TextToSpeech from './components/TextToSpeech';
import ImageAnalyzer from './components/ImageAnalyzer';
import ImageEditor from './components/ImageEditor';
import VideoEditor from './components/VideoEditor';
import VideoAnalyzer from './components/VideoAnalyzer';
import AnimeProductionStudio from './components/AnimeProductionStudio';
import EbookGenerator from './components/EbookGenerator';
import UniverseAICore from './components/UniverseAICore';
import Home from './components/Home';
import MainLayout from './components/layout/MainLayout';
import { NotificationProvider } from './context/NotificationContext';
import ImageToVideo from './components/ImageToVideo';
import LyriaAI from './components/LyriaAI';

const getInitialState = <T,>(key: string, defaultValue: T): T => {
    try {
        const savedState = localStorage.getItem(key);
        return savedState ? JSON.parse(savedState) : defaultValue;
    } catch (error) {
        console.error(`Failed to parse ${key} from localStorage`, error);
        return defaultValue;
    }
};


const App: React.FC = () => {
  const [activeFeature, setActiveFeature] = useState<Feature>(() => {
    const savedFeature = localStorage.getItem('active_feature') as Feature;
    return Object.values(Feature).includes(savedFeature) ? savedFeature : Feature.Home;
  });
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(() => getInitialState('sidebar_collapsed', false));

  useEffect(() => {
    localStorage.setItem('active_feature', activeFeature);
  }, [activeFeature]);

  const toggleSidebar = () => {
      setIsSidebarCollapsed(prev => {
          const newState = !prev;
          localStorage.setItem('sidebar_collapsed', JSON.stringify(newState));
          return newState;
      });
  }

  const renderFeature = () => {
    switch (activeFeature) {
      case Feature.Home:
        return <Home setActiveFeature={setActiveFeature} />;
      case Feature.UniverseAICore:
        return <UniverseAICore />;
      case Feature.ImageGeneration:
        return <ImageGenerator />;
      case Feature.ImageEditing:
        return <ImageEditor />;
      case Feature.VideoEditing:
        return <VideoEditor />;
      case Feature.ImageToVideo:
        return <ImageToVideo />;
      case Feature.AnimeProductionStudio:
        return <AnimeProductionStudio />;
      case Feature.ImageAnalysis:
        return <ImageAnalyzer />;
      case Feature.VideoGeneration:
        return <VideoGenerator />;
      case Feature.VideoAnalysis:
        return <VideoAnalyzer />;
      case Feature.LiveConversation:
        return <LiveConversation />;
      case Feature.GroundingSearch:
        return <GroundingSearch />;
      case Feature.TextToSpeech:
        return <TextToSpeech />;
      case Feature.EbookGeneration:
        return <EbookGenerator />;
      case Feature.LyriaAI:
        return <LyriaAI />;
      default:
        return <Home setActiveFeature={setActiveFeature} />;
    }
  };

  return (
    <NotificationProvider>
      <div className="flex h-screen bg-gray-950 text-gray-100 font-sans">
        <Sidebar 
          activeFeature={activeFeature} 
          setActiveFeature={setActiveFeature}
          isCollapsed={isSidebarCollapsed}
          toggleSidebar={toggleSidebar} 
        />
        <MainLayout activeFeature={activeFeature} isSidebarCollapsed={isSidebarCollapsed}>
          {renderFeature()}
        </MainLayout>
      </div>
    </NotificationProvider>
  );
};

export default App;