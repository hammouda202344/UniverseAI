
import { FunctionCall } from "@google/genai";

export enum Feature {
  Home = 'Home',
  UniverseAICore = 'UniverseAI Core',
  CreativeMuse = 'Creative Muse',
  ImageGeneration = 'Image Generation',
  ImageEditing = 'Image Editing',
  VideoEditing = 'Video Editing',
  ImageToVideo = 'Image to Video',
  AnimeProductionStudio = 'Anime Production Studio',
  ImageAnalysis = 'Image Analysis',
  VideoGeneration = 'Video Generation',
  VideoAnalysis = 'Video Analysis',
  LiveConversation = 'Live Conversation',
  GroundingSearch = 'Grounding Search',
  TextToSpeech = 'Text to Speech',
  EbookGeneration = 'Ebook Generation',
  LyriaAI = 'Lyria AI',
}

export interface ContextFile {
    name: string;
    type: 'image' | 'text' | 'pdf';
    mimeType: string;
    content: string; // base64 for image, text content for text/pdf
}

interface ToolCallState {
  toolName: 'web_search' | 'generate_image';
  args: any;
  status: 'pending' | 'executing' | 'complete';
  result?: any;
}

export interface CoreMessage {
  id: string;
  role: 'user' | 'model' | 'tool';
  text?: string;
  toolCalls?: FunctionCall[];
  toolResponse?: {
      id: string;
      name: string;
      response: any;
  };
  imageContent?: string; // For generated images
  contextFiles?: ContextFile[];
  isError?: boolean;
}

// State for visualizing the cognitive process
export interface CognitiveState {
    status: 'idle' | 'analyzing' | 'thinking' | 'tool_calling' | 'responding';
    activeTools: ToolCallState[];
}


export interface ChatMessage {
  role: 'user' | 'model';
  parts: { text: string }[];
}

export type LoadingState = 'idle' | 'loading' | 'success' | 'error';

// FIX: Made properties optional to align with the GroundingChunk type from the @google/genai SDK.
export interface GroundingChunk {
  web?: {
    uri?: string;
    title?: string;
  };
  maps?: {
    uri?: string;
    title?: string;
    placeAnswerSources?: {
        reviewSnippets?: {
            uri?: string;
            text?: string;
        }[];
    }[];
  };
}

export type NotificationType = 'success' | 'error' | 'info';

export interface Notification {
  id: number;
  message: string;
  type: NotificationType;
}