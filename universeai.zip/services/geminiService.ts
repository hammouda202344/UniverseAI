

import { GoogleGenAI, Chat, GenerateContentResponse, Modality, Type, FunctionDeclaration, Part } from "@google/genai";
import { ChatMessage, GroundingChunk, ContextFile } from "../types";

// --- FILE UTILITIES ---

export const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.onerror = (error) => reject(error);
    });
};

export const fileToText = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsText(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = (error) => reject(error);
    });
};

declare const pdfjsLib: any; // From script tag in index.html

export const pdfToText = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
    let textContent = '';
    for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const text = await page.getTextContent();
        textContent += text.items.map((item: any) => item.str).join(' ');
    }
    return textContent;
};

export const fileToDataURL = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = (error) => reject(error);
        reader.readAsDataURL(file);
    });
};

export const blobToDataURL = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = (error) => reject(error);
        reader.readAsDataURL(blob);
    });
};

export const dataURLtoFile = (dataurl: string, filename: string): File | null => {
    const arr = dataurl.split(',');
    if (arr.length < 2) { return null; }
    const mimeMatch = arr[0].match(/:(.*?);/);
    if (!mimeMatch || mimeMatch.length < 2) { return null; }
    const mime = mimeMatch[1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    while(n--){
        u8arr[n] = bstr.charCodeAt(n);
    }
    return new File([u8arr], filename, {type:mime});
};


// --- UNIVERSE AI CORE Service ---

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const webSearchTool: FunctionDeclaration = {
    name: 'web_search',
    parameters: {
        type: Type.OBJECT,
        description: 'Performs a web search to get up-to-date information on a given topic.',
        properties: {
            query: { type: Type.STRING, description: 'The search query.' },
        },
        required: ['query'],
    }
};

const generateImageTool: FunctionDeclaration = {
    name: 'generate_image',
    parameters: {
        type: Type.OBJECT,
        description: 'Generates an image based on a descriptive prompt.',
        properties: {
            prompt: { type: Type.STRING, description: 'A detailed description of the image to generate.' },
        },
        required: ['prompt'],
    }
};

const executeWebSearch = async (query: string): Promise<{ result: string }> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Summarize the web search results for the query: "${query}"`,
            config: { tools: [{ googleSearch: {} }] },
        });
        const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
        const sources = groundingChunks.map(c => c.web?.uri).filter(Boolean).join('\n');
        return { result: `${response.text}\n\nSources:\n${sources}` };
    } catch (e) {
        console.error("Web search tool failed:", e);
        return { result: "The web search failed. Please try again." };
    }
};

const executeImageGeneration = async (prompt: string): Promise<{ imageUrl: string }> => {
     try {
        const response = await ai.models.generateImages({
            model: 'imagen-4.0-generate-001',
            prompt,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/jpeg',
                aspectRatio: "1:1",
            },
        });
        const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
        return { imageUrl: `data:image/jpeg;base64,${base64ImageBytes}` };
    } catch (e) {
        console.error("Image generation tool failed:", e);
        return { imageUrl: "ERROR: Image could not be generated." };
    }
};

const buildCorePrompt = (prompt: string, files: ContextFile[]): Part[] => {
    let parts: Part[] = [];
    let textPrompt = '';

    if (files.length > 0) {
        textPrompt += 'Use the following context provided by the user to answer their prompt.\n\n--- CONTEXT START ---\n';
        files.forEach(file => {
            if (file.type === 'image') {
                parts.push({ inlineData: { mimeType: file.mimeType, data: file.content }});
                textPrompt += `[CONTEXT IMAGE: ${file.name}]\n`;
            } else {
                textPrompt += `[CONTEXT DOCUMENT: ${file.name}]\n${file.content}\n\n`;
            }
        });
        textPrompt += '--- CONTEXT END ---\n\n';
    }
    
    textPrompt += `User Prompt: "${prompt}"`;
    parts.unshift({ text: textPrompt });
    return parts;
};

export const universeCore_run = (prompt: string, contextFiles: ContextFile[]): { chat: Chat, streamPromise: Promise<AsyncGenerator<GenerateContentResponse>> } => {
    const chat = ai.chats.create({
        model: 'gemini-2.5-pro',
        config: {
            systemInstruction: `You are UniverseAI, a powerful, multi-modal AI assistant. You can autonomously use tools like web search and image generation to fulfill user requests. Be helpful, proactive, and clear. When using tools, inform the user what you are doing.`,
            tools: [{ functionDeclarations: [webSearchTool, generateImageTool] }]
        }
    });
    
    const parts = buildCorePrompt(prompt, contextFiles);
    const streamPromise = chat.sendMessageStream({ message: parts });
    return { chat, streamPromise: Promise.resolve(streamPromise) };
};

export const universeCore_executeTool = async (name: string, args: any) => {
    if (name === 'web_search') {
        return executeWebSearch(args.query);
    }
    if (name === 'generate_image') {
        return executeImageGeneration(args.prompt);
    }
    return { error: `Unknown tool: ${name}` };
};

// --- OTHER FEATURES ---

export const createChatSession = (history: ChatMessage[] = []): Chat => {
    return ai.chats.create({
        model: 'gemini-2.5-flash',
        history,
    });
};

export const generateImage = async (prompt: string, aspectRatio: string, model: 'imagen-4.0-generate-001' | 'gemini-2.5-flash-image'): Promise<string> => {
    if (model === 'imagen-4.0-generate-001') {
        const response = await ai.models.generateImages({
            model: 'imagen-4.0-generate-001',
            prompt,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/jpeg',
                aspectRatio: aspectRatio as "1:1" | "3:4" | "4:3" | "9:16" | "16:9",
            },
        });
        return `data:image/jpeg;base64,${response.generatedImages[0].image.imageBytes}`;
    } else { // gemini-2.5-flash-image
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: {
                parts: [{ text: prompt }],
            },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });
        for (const part of response.candidates![0]!.content!.parts) {
            if (part.inlineData) {
                return `data:image/png;base64,${part.inlineData.data}`;
            }
        }
        throw new Error("No image generated by Gemini Flash Image model.");
    }
};

export const editImage = async (prompt: string, imageFile: File): Promise<string> => {
    const base64Data = await fileToBase64(imageFile);
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
            parts: [
                { inlineData: { data: base64Data, mimeType: imageFile.type } },
                { text: prompt },
            ],
        },
        config: { responseModalities: [Modality.IMAGE] },
    });

    const candidate = response.candidates?.[0];
    const imagePart = candidate?.content?.parts?.find(part => part.inlineData);

    if (imagePart?.inlineData) {
        return `data:image/png;base64,${imagePart.inlineData.data}`;
    }

    const finishReason = candidate?.finishReason;
    if (finishReason === 'SAFETY') {
        throw new Error("Request was blocked for safety reasons. Please modify your prompt or image.");
    }
    
    console.error("Image editing failed. Full response:", response);
    throw new Error("Failed to generate edited image. The model did not return an image.");
};

export const analyzeImage = async (prompt: string, imageFile: File): Promise<string> => {
    const imagePart = { inlineData: { mimeType: imageFile.type, data: await fileToBase64(imageFile) } };
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [imagePart, { text: prompt }] },
    });
    return response.text;
};

export const generateVideo = (prompt: string, imageFile: File | null, aspectRatio: '16:9' | '9:16', model: string, resolution: '720p' | '1080p' = '720p') => {
    const veo_ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
    const config = { numberOfVideos: 1, resolution, aspectRatio };
    if (imageFile) {
        return fileToBase64(imageFile).then(base64Data => {
            return veo_ai.models.generateVideos({ model, prompt, image: { imageBytes: base64Data, mimeType: imageFile.type }, config });
        });
    } else {
        return veo_ai.models.generateVideos({ model, prompt, config });
    }
};

export const pollVideoOperation = (operation: any) => {
    const veo_ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
    return veo_ai.operations.getVideosOperation({ operation: operation });
};

export const analyzeVideo = async (prompt: string, frames: string[]): Promise<string> => {
    const imageParts = frames.map(frame => ({ inlineData: { mimeType: 'image/jpeg', data: frame } }));
    const response = await ai.models.generateContent({ model: 'gemini-2.5-pro', contents: { parts: [{ text: prompt }, ...imageParts] } });
    return response.text;
};

export const groundedSearch = async (query: string, useMaps: boolean, location: GeolocationCoordinates | null): Promise<{ text: string, chunks: GroundingChunk[] }> => {
    const tools: any[] = [{ googleSearch: {} }];
    if (useMaps) tools.push({ googleMaps: {} });
    const config: any = { tools };
    if (useMaps && location) {
        config.toolConfig = { retrievalConfig: { latLng: { latitude: location.latitude, longitude: location.longitude } } };
    }
    const response = await ai.models.generateContent({ model: "gemini-2.5-flash", contents: query, config });
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    return { text: response.text, chunks };
};

export const textToSpeech = async (text: string, voice: string): Promise<string> => {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data ?? "";
};

export const generateEbook = async (prompt: string): Promise<{ title: string; chapters: { title: string; content: string }[] }> => {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: `Generate a short ebook based on the following topic: "${prompt}". The book should have a main title and at least 3 chapters. For each chapter, provide a chapter title and the chapter content.`,
        config: {
            responseMimeType: "application/json",
            responseSchema: { 
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING },
                    chapters: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                title: { type: Type.STRING },
                                content: { type: Type.STRING }
                            },
                            required: ["title", "content"]
                        }
                    }
                },
                required: ["title", "chapters"]
             }
        },
    });
    return JSON.parse(response.text.trim());
};

// FIX: Implemented audio encoding/decoding functions that were previously placeholders.
export function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}
export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
export function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export const createLiveSession = (callbacks: any) => {
    return ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks,
        config: { 
            responseModalities: [Modality.AUDIO],
            inputAudioTranscription: {},
            outputAudioTranscription: {}
        },
    });
};

// --- Lyria AI Service ---

interface Composition {
    vocalAudio: string; // base64 encoded audio
    lyrics: string;
    instrumentalDescription: string;
    title: string;
}

export const generateComposition = async (
    prompt: string,
    genre: string,
    mood: string,
    instruments: string[]
): Promise<Composition> => {
    // Step 1: Generate the song structure, lyrics, and instrumental description with Gemini Pro.
    const generationPrompt = `
        You are an expert songwriter and music composer. Generate a short song based on the following user request.
        The song should have a title, lyrics for one verse and one chorus, and a description of the instrumental arrangement.
        
        User Prompt: "${prompt}"
        Genre: ${genre}
        Mood: ${mood}
        Instruments: ${instruments.join(', ')}

        Provide the output in JSON format. The lyrics should be formatted with newlines.
        For the vocal melody, provide a descriptive instruction for a text-to-speech model on how to perform the lyrics (e.g., 'sing in a soft, melancholic tone', 'rap with an upbeat, energetic rhythm').
    `;

    const modelResponse = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: generationPrompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING, description: "The title of the song." },
                    lyrics: { type: Type.STRING, description: "The full lyrics for the song (verse and chorus), formatted with newlines." },
                    instrumentalDescription: { type: Type.STRING, description: "A description of the instruments and arrangement." },
                    vocalPerformanceInstruction: { type: Type.STRING, description: "Instruction for the TTS model on how to perform the vocals."}
                },
                required: ["title", "lyrics", "instrumentalDescription", "vocalPerformanceInstruction"]
            }
        },
    });

    const compositionPlan = JSON.parse(modelResponse.text.trim());

    // Step 2: Generate the vocal audio using the TTS model.
    const ttsPrompt = `Say with ${compositionPlan.vocalPerformanceInstruction}: ${compositionPlan.lyrics}`;
    const vocalAudio = await textToSpeech(ttsPrompt, 'Kore'); // Using 'Kore' as a versatile female voice.

    return {
        vocalAudio: vocalAudio,
        lyrics: compositionPlan.lyrics,
        instrumentalDescription: compositionPlan.instrumentalDescription,
        title: compositionPlan.title
    };
};


export const transformComposition = async (
    originalComposition: { title: string; lyrics: string; instrumentalDescription: string },
    transformPrompt: string
): Promise<Composition> => {
    // Step 1: Generate the transformed song structure
    const generationPrompt = `
        You are an expert music producer specializing in remixes and style transformations.
        Take the following song and transform it based on the user's request.
        
        Original Song:
        Title: "${originalComposition.title}"
        Lyrics:
        ${originalComposition.lyrics}
        Instrumental Description: ${originalComposition.instrumentalDescription}

        User's Transformation Request: "${transformPrompt}"

        Generate a new title, new lyrics (if appropriate for the transformation), a new instrumental description, and a new vocal performance instruction.
        Provide the output in JSON format.
    `;

     const modelResponse = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: generationPrompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING, description: "The new title of the transformed song." },
                    lyrics: { type: Type.STRING, description: "The new lyrics for the song, formatted with newlines." },
                    instrumentalDescription: { type: Type.STRING, description: "A new description of the instruments and arrangement." },
                    vocalPerformanceInstruction: { type: Type.STRING, description: "A new instruction for the TTS model on how to perform the vocals."}
                },
                required: ["title", "lyrics", "instrumentalDescription", "vocalPerformanceInstruction"]
            }
        },
    });

    const compositionPlan = JSON.parse(modelResponse.text.trim());

    // Step 2: Generate the new vocal audio
    const ttsPrompt = `Say with ${compositionPlan.vocalPerformanceInstruction}: ${compositionPlan.lyrics}`;
    const vocalAudio = await textToSpeech(ttsPrompt, 'Puck'); // Using a different voice for transformation

     return {
        vocalAudio: vocalAudio,
        lyrics: compositionPlan.lyrics,
        instrumentalDescription: compositionPlan.instrumentalDescription,
        title: compositionPlan.title
    };
}

// --- ANIME PRODUCTION STUDIO Service ---

export const generateCharacterSheet = async (prompt: string, style: string) => {
    const systemInstruction = `You are a creative writer and character designer for an anime studio. Generate a detailed character sheet in JSON format based on the user's concept and chosen style. The sheet should include: name, backstory (2-3 sentences), personality (3-4 keywords), and visualTraits (a detailed list of physical features, clothing, and accessories). Then, combine all this information into a single, comprehensive 'fullPrompt' string, optimized for an AI image generation model like Imagen.`;

    const userPrompt = `Character Concept: "${prompt}", Style: "${style}"`;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: userPrompt,
        config: {
            systemInstruction,
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    sheet: {
                        type: Type.OBJECT,
                        properties: {
                            name: { type: Type.STRING },
                            backstory: { type: Type.STRING },
                            personality: { type: Type.STRING },
                            visualTraits: { type: Type.STRING },
                        },
                         required: ["name", "backstory", "personality", "visualTraits"]
                    },
                    fullPrompt: { type: Type.STRING }
                },
                required: ["sheet", "fullPrompt"]
            }
        }
    });

    return JSON.parse(response.text.trim());
};

export const generateStoryboards = async (sceneDescription: string, characterImage: File, characterSheet: any): Promise<{ panels: { image: string; description: string; }[] }> => {
    const base64Image = await fileToBase64(characterImage);
    const imagePart = { inlineData: { mimeType: characterImage.type, data: base64Image } };
    
    const prompt = `
        You are an anime storyboard artist. Based on the provided character design and scene description, create a sequence of 3-4 storyboard panels.
        
        Character: ${characterSheet.name}. ${characterSheet.personality}.
        Scene Description: "${sceneDescription}"

        For each panel, generate a new image that visually represents a key moment in the scene, maintaining the character's appearance from the reference image. Also provide a brief "shot description" for each panel (e.g., "Medium shot, character looks over their shoulder", "Close up on character's determined face").

        Return an array of panel objects.
    `;

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: { parts: [{ text: prompt }, imagePart] },
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    panels: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                image: { 
                                    type: Type.STRING, 
                                    description: "A highly detailed prompt for an AI image generator to create the storyboard panel. It MUST include the character's description and the specific action for this panel."
                                },
                                description: { 
                                    type: Type.STRING,
                                    description: "The shot description for this panel."
                                }
                            },
                             required: ["image", "description"]
                        }
                    }
                },
                 required: ["panels"]
            }
        }
    });

    const storyboardPlan = JSON.parse(response.text.trim());

    // Now, generate an image for each panel description
    const generatedPanels = await Promise.all(storyboardPlan.panels.map(async (panel: any) => {
        const imageUrl = await generateImage(panel.image, "16:9", "imagen-4.0-generate-001");
        return {
            image: imageUrl,
            description: panel.description,
        };
    }));
    
    return { panels: generatedPanels };
};

export const generateScenePolish = async (sceneDescription: string, characterSheet: any): Promise<{ soundDesign: string; dialogue: string; }> => {
     const prompt = `
        You are a post-production supervisor for an anime. Given the scene and character, provide final creative touches.

        Character: ${characterSheet.name}, who is ${characterSheet.personality}.
        Scene: "${sceneDescription}"

        Generate a 'soundDesign' concept (1-2 sentences describing ambient sounds, sound effects, and music cues) and one line of 'dialogue' the character might say in this moment.
    `;
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
            responseMimeType: 'application/json',
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    soundDesign: { type: Type.STRING },
                    dialogue: { type: Type.STRING },
                },
                required: ['soundDesign', 'dialogue'],
            },
        },
    });

    return JSON.parse(response.text.trim());
};